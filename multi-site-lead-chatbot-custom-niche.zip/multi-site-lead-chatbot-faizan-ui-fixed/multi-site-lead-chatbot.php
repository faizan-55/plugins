<?php
/**
 * Plugin Name: Multi-Site Lead Chatbot
 * Description: Rule-based lead chatbot for WordPress websites with Telegram group topics per visitor and human takeover support.
 * Version: 1.8.0
 * Author: Faizan Ali
 */

if (!defined('ABSPATH')) exit;

class MSLC_Plugin {
    private $option = 'mslc_settings';

    public function __construct() {
        register_activation_hook(__FILE__, [$this, 'activate']);
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'admin_enqueue_assets']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_footer', [$this, 'render_widget']);

        add_action('wp_ajax_mslc_start_chat', [$this, 'ajax_start_chat']);
        add_action('wp_ajax_nopriv_mslc_start_chat', [$this, 'ajax_start_chat']);
        add_action('wp_ajax_mslc_send_message', [$this, 'ajax_send_message']);
        add_action('wp_ajax_nopriv_mslc_send_message', [$this, 'ajax_send_message']);
        add_action('wp_ajax_mslc_submit_lead', [$this, 'ajax_submit_lead']);
        add_action('wp_ajax_nopriv_mslc_submit_lead', [$this, 'ajax_submit_lead']);
        add_action('wp_ajax_mslc_get_messages', [$this, 'ajax_get_messages']);
        add_action('wp_ajax_nopriv_mslc_get_messages', [$this, 'ajax_get_messages']);
        add_action('rest_api_init', [$this, 'register_telegram_routes']);
        add_action('admin_post_mslc_set_telegram_webhook', [$this, 'admin_set_telegram_webhook']);
                add_action('init', [$this, 'maybe_upgrade_db']);
    }

    public function defaults() {
        return [
            'site_id' => sanitize_title(get_bloginfo('name')),
            'website_name' => get_bloginfo('name'),
            'category' => 'sliding_door',
            'telegram_bot_token' => '',
            'telegram_group_id' => '',
            'telegram_thread_id' => '',
            'telegram_enabled' => '1',
            'admin_live_mode' => '0',
            'widget_enabled' => '1',
            'conversation_rules' => "price|cost|quote => I can get that checked for you.
service|repair|install => Sure, we can help with that.
location|area => Yes, we can check availability in your area.",
            'initial_buttons' => "Get Quote
Request Service
Talk To Human",
            'service_buttons_custom' => '',
            'custom_niche_name' => '',
            'custom_niche_keywords' => '',
            'telegram_topic_name' => get_bloginfo('name'),
            'widget_primary_color' => '#1266f1',
            'widget_header_color' => '#1266f1',
            'widget_bot_bubble_color' => '#ffffff',
            'widget_user_bubble_color' => '#1266f1',
            'widget_icon' => '💬',
            'widget_icon_bg_color' => '#1266f1',
            'widget_icon_text_color' => '#ffffff',
            'chat_bottom_padding' => '8',
            'admin_avatar_url' => '',
            'chat_header_title' => 'Questions? Chat with us.',
            'chat_reply_time_text' => 'Typically replies under 41 minutes.'
        ];
    }

    public function get_settings() {
        return wp_parse_args(get_option($this->option, []), $this->defaults());
    }

    public function activate() {
        $this->install_tables();
        if (!get_option($this->option)) update_option($this->option, $this->defaults());
        update_option('mslc_db_version', '1.6.4');
    }

    public function maybe_upgrade_db() {
        if (get_option('mslc_db_version') !== '1.6.4') {
            $this->install_tables();
            update_option('mslc_db_version', '1.6.4');
        }
    }

    private function install_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $leads = $wpdb->prefix . 'mslc_leads';
        $chats = $wpdb->prefix . 'mslc_chats';
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        dbDelta("CREATE TABLE $leads (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            site_id VARCHAR(100) NOT NULL,
            website_name VARCHAR(255) NOT NULL,
            category VARCHAR(100) NOT NULL,
            visitor_session VARCHAR(255) NOT NULL,
            service_type VARCHAR(255) NULL,
            name VARCHAR(255) NULL,
            phone VARCHAR(100) NULL,
            email VARCHAR(255) NULL,
            city VARCHAR(255) NULL,
            message TEXT NULL,
            extra_data LONGTEXT NULL,
            status VARCHAR(50) DEFAULT 'New',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset;");

        dbDelta("CREATE TABLE $chats (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            site_id VARCHAR(100) NOT NULL,
            visitor_session VARCHAR(255) NOT NULL,
            sender VARCHAR(50) NOT NULL,
            message TEXT NOT NULL,
            takeover TINYINT DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset;");
    }

    public function admin_menu() {
        add_menu_page('Lead Chatbot', 'Lead Chatbot', 'manage_options', 'mslc-settings', [$this, 'settings_page'], 'dashicons-format-chat', 56);
        add_submenu_page('mslc-settings', 'Leads', 'Leads', 'manage_options', 'mslc-leads', [$this, 'leads_page']);
    }

    public function register_settings() {
        register_setting('mslc_settings_group', $this->option, [$this, 'sanitize_settings']);
    }

    public function sanitize_settings($input) {
        $existing = get_option($this->option, []);
        if (!is_array($existing)) $existing = [];
        return [
            'site_id' => sanitize_text_field($input['site_id'] ?? ''),
            'website_name' => sanitize_text_field($input['website_name'] ?? ''),
            'category' => sanitize_text_field($input['category'] ?? 'sliding_door'),
            'telegram_bot_token' => sanitize_text_field($input['telegram_bot_token'] ?? ''),
            'telegram_group_id' => sanitize_text_field($input['telegram_group_id'] ?? ''),
            'telegram_thread_id' => sanitize_text_field($input['telegram_thread_id'] ?? ''),
            'telegram_enabled' => !empty($input['telegram_enabled']) ? '1' : '0',
            // Admin live mode is controlled only from Telegram commands (/online and /offline).
            // Do not change it from the WordPress settings form.
            'admin_live_mode' => (string)($existing['admin_live_mode'] ?? '0'),
            'widget_enabled' => !empty($input['widget_enabled']) ? '1' : '0',
            'conversation_rules' => sanitize_textarea_field($input['conversation_rules'] ?? ''),
            'initial_buttons' => sanitize_textarea_field($input['initial_buttons'] ?? ''),
            'service_buttons_custom' => sanitize_textarea_field($input['service_buttons_custom'] ?? ''),
            'custom_niche_name' => sanitize_text_field($input['custom_niche_name'] ?? ''),
            'custom_niche_keywords' => sanitize_textarea_field($input['custom_niche_keywords'] ?? ''),
            'telegram_topic_name' => sanitize_text_field($input['telegram_topic_name'] ?? ''),
            'widget_primary_color' => sanitize_hex_color($input['widget_primary_color'] ?? '#1266f1') ?: '#1266f1',
            'widget_header_color' => sanitize_hex_color($input['widget_header_color'] ?? '#1266f1') ?: '#1266f1',
            'widget_bot_bubble_color' => sanitize_hex_color($input['widget_bot_bubble_color'] ?? '#ffffff') ?: '#ffffff',
            'widget_user_bubble_color' => sanitize_hex_color($input['widget_user_bubble_color'] ?? '#1266f1') ?: '#1266f1',
            'widget_icon' => sanitize_text_field($input['widget_icon'] ?? '💬'),
            'widget_icon_bg_color' => sanitize_hex_color($input['widget_icon_bg_color'] ?? '#1266f1') ?: '#1266f1',
            'widget_icon_text_color' => sanitize_hex_color($input['widget_icon_text_color'] ?? '#ffffff') ?: '#ffffff',
            'chat_bottom_padding' => (string) max(0, min(40, absint($input['chat_bottom_padding'] ?? 8))),
            'admin_avatar_url' => esc_url_raw($input['admin_avatar_url'] ?? ''),
            'chat_header_title' => sanitize_text_field($input['chat_header_title'] ?? 'Questions? Chat with us.'),
            'chat_reply_time_text' => sanitize_text_field($input['chat_reply_time_text'] ?? 'Typically replies under 41 minutes.')
        ];
    }


    public function admin_enqueue_assets($hook) {
        if ($hook !== 'toplevel_page_mslc-settings') return;
        wp_enqueue_media();
        $js = <<<'JS'
jQuery(function($){
  $(document).on('click','.mslc-upload-avatar',function(e){
    e.preventDefault();
    var target=$($(this).data('target'));
    var frame=wp.media({title:'Choose Admin Image',button:{text:'Use this image'},multiple:false});
    frame.on('select',function(){
      var a=frame.state().get('selection').first().toJSON();
      target.val(a.url).trigger('change');
      $('.mslc-avatar-preview').attr('src',a.url).show();
    });
    frame.open();
  });
  $(document).on('click','.mslc-remove-avatar',function(e){
    e.preventDefault();
    $('#mslc_admin_avatar_url').val('');
    $('.mslc-avatar-preview').hide();
  });
  function mslcToggleCustomNiche(){
    var isCustom = $('#mslc_category_select').val() === 'custom';
    $('.mslc-custom-niche-row').toggle(isCustom);
  }
  $('#mslc_category_select').on('change', mslcToggleCustomNiche);
  mslcToggleCustomNiche();
});
JS;
        wp_add_inline_script('jquery-core', $js);
    }

    public function settings_page() {
        $s = $this->get_settings();
        ?>
        <div class="wrap">
            <h1>Multi-Site Lead Chatbot Settings</h1>
            <?php if (isset($_GET['mslc_webhook'])): ?>
                <?php if ($_GET['mslc_webhook'] === 'success'): ?>
                    <div class="notice notice-success is-dismissible"><p>Telegram takeover webhook enabled successfully.</p></div>
                <?php elseif ($_GET['mslc_webhook'] === 'failed'): ?>
                    <div class="notice notice-error is-dismissible"><p>Telegram webhook could not be enabled. Please check bot token and SSL/HTTPS on your website.</p></div>
                <?php elseif ($_GET['mslc_webhook'] === 'missing_token'): ?>
                    <div class="notice notice-warning is-dismissible"><p>Please save your Telegram bot token first.</p></div>
                <?php endif; ?>
            <?php endif; ?>
            <form method="post" action="options.php">
                <?php settings_fields('mslc_settings_group'); ?>
                <table class="form-table">
                    <tr><th>Enable Widget</th><td><input type="checkbox" name="<?php echo esc_attr($this->option); ?>[widget_enabled]" value="1" <?php checked($s['widget_enabled'], '1'); ?>></td></tr>
                    <tr><th>Human Chat Rules</th><td><textarea class="large-text code" rows="8" name="<?php echo esc_attr($this->option); ?>[conversation_rules]"><?php echo esc_textarea($s['conversation_rules'] ?? ''); ?></textarea><p class="description">Optional training rules. One per line: keywords separated by |, then =>, then one-line reply. Example: price|cost => Sure, may I have your name?</p></td></tr>
                    <tr><th>Site ID</th><td><input class="regular-text" name="<?php echo esc_attr($this->option); ?>[site_id]" value="<?php echo esc_attr($s['site_id']); ?>"><p class="description">Example: fastfix, walltech, unitedpro</p></td></tr>
                    <tr><th>Website Name</th><td><input class="regular-text" name="<?php echo esc_attr($this->option); ?>[website_name]" value="<?php echo esc_attr($s['website_name']); ?>"></td></tr>
                    <tr><th>Category</th><td><select id="mslc_category_select" name="<?php echo esc_attr($this->option); ?>[category]">
                        <?php foreach ($this->categories() as $k=>$v): ?>
                            <option value="<?php echo esc_attr($k); ?>" <?php selected($s['category'], $k); ?>><?php echo esc_html($v); ?></option>
                        <?php endforeach; ?>
                    </select><p class="description">Pick a ready-made niche, or choose "Custom / My Own Business" to define your own below.</p></td></tr>
                    <tr class="mslc-custom-niche-row"><th>Custom Niche Name</th><td><input class="regular-text" name="<?php echo esc_attr($this->option); ?>[custom_niche_name]" value="<?php echo esc_attr($s['custom_niche_name'] ?? ''); ?>" placeholder="e.g. Plumbing, Roofing, Pet Grooming"><p class="description">Only used when Category is set to "Custom / My Own Business". A short name for your business type.</p></td></tr>
                    <tr><th>Allowed Website Services</th><td><textarea class="large-text code" rows="5" name="<?php echo esc_attr($this->option); ?>[service_buttons_custom]"><?php echo esc_textarea($s['service_buttons_custom'] ?? ''); ?></textarea><p class="description">One service per line. The bot will only confirm these services for this website. Leave blank to use the selected category services.</p></td></tr>
                    <tr class="mslc-custom-niche-row"><th>Custom Niche Keywords</th><td><textarea class="large-text code" rows="4" name="<?php echo esc_attr($this->option); ?>[custom_niche_keywords]"><?php echo esc_textarea($s['custom_niche_keywords'] ?? ''); ?></textarea><p class="description">Only used when Category is set to "Custom / My Own Business". One keyword or phrase per line (or comma separated) that the bot should recognize as being in-scope, e.g. leaking pipe, drain cleaning, water heater. These help the bot detect and reject out-of-scope requests correctly.</p></td></tr>
                    <tr><th>Enable Telegram</th><td><input type="checkbox" name="<?php echo esc_attr($this->option); ?>[telegram_enabled]" value="1" <?php checked($s['telegram_enabled'], '1'); ?>></td></tr>
                    <tr><th>Telegram Bot Token</th><td><input type="password" autocomplete="off" class="regular-text" name="<?php echo esc_attr($this->option); ?>[telegram_bot_token]" value="<?php echo esc_attr($s['telegram_bot_token']); ?>"><p class="description">From @BotFather. Keep private.</p></td></tr>
                    <tr><th>Telegram Group ID</th><td><input class="regular-text" name="<?php echo esc_attr($this->option); ?>[telegram_group_id]" value="<?php echo esc_attr($s['telegram_group_id']); ?>"><p class="description">Supergroup ID where each visitor will get a separate Telegram topic. Add the bot as admin with Manage Topics permission. Leave blank, enable webhook, then send /id in the group to auto-save it.</p></td></tr>
                    <tr style="display:none"><th>Telegram Thread / Topic ID</th><td><input class="regular-text" name="<?php echo esc_attr($this->option); ?>[telegram_thread_id]" value=""><p class="description">Auto-created per visitor. No manual topic ID needed.</p></td></tr>
                    <tr style="display:none"><th>Telegram Topic Name</th><td><input class="regular-text" name="<?php echo esc_attr($this->option); ?>[telegram_topic_name]" value="<?php echo esc_attr($s['telegram_topic_name'] ?? $s['website_name']); ?>"></td></tr>
                    <tr><th colspan="2"><h2 style="margin:20px 0 0">Frontend Chat Style</h2></th></tr>
                    <tr><th>Chat Bottom Padding</th><td><input type="number" min="0" max="40" class="small-text" name="<?php echo esc_attr($this->option); ?>[chat_bottom_padding]" value="<?php echo esc_attr($s['chat_bottom_padding'] ?? '8'); ?>"> px<p class="description">Controls the space around the message input area. Recommended: 6–10px.</p></td></tr>
                    <tr><th>Primary Color</th><td><input type="color" name="<?php echo esc_attr($this->option); ?>[widget_primary_color]" value="<?php echo esc_attr($s['widget_primary_color'] ?? '#1266f1'); ?>"> <span class="description">Buttons, borders, and active accents.</span></td></tr>
                    <tr><th>Header Color</th><td><input type="color" name="<?php echo esc_attr($this->option); ?>[widget_header_color]" value="<?php echo esc_attr($s['widget_header_color'] ?? '#1266f1'); ?>"></td></tr>
                    <tr><th>User Message Color</th><td><input type="color" name="<?php echo esc_attr($this->option); ?>[widget_user_bubble_color]" value="<?php echo esc_attr($s['widget_user_bubble_color'] ?? '#1266f1'); ?>"></td></tr>
                    <tr><th>Bot Message Color</th><td><input type="color" name="<?php echo esc_attr($this->option); ?>[widget_bot_bubble_color]" value="<?php echo esc_attr($s['widget_bot_bubble_color'] ?? '#ffffff'); ?>"></td></tr>
                    <tr><th>Admin Image</th><td><input id="mslc_admin_avatar_url" class="regular-text" name="<?php echo esc_attr($this->option); ?>[admin_avatar_url]" value="<?php echo esc_attr($s['admin_avatar_url'] ?? ''); ?>"> <button type="button" class="button mslc-upload-avatar" data-target="#mslc_admin_avatar_url">Upload Image</button> <button type="button" class="button mslc-remove-avatar">Remove</button><br><?php if (!empty($s['admin_avatar_url'])): ?><img class="mslc-avatar-preview" src="<?php echo esc_url($s['admin_avatar_url']); ?>" style="width:58px;height:58px;border-radius:50%;object-fit:cover;margin-top:8px"><?php else: ?><img class="mslc-avatar-preview" src="" style="width:58px;height:58px;border-radius:50%;object-fit:cover;margin-top:8px;display:none"><?php endif; ?><p class="description">This image appears in the chat header and beside admin/bot messages.</p></td></tr>
                    <tr><th>Header Title</th><td><input class="regular-text" name="<?php echo esc_attr($this->option); ?>[chat_header_title]" value="<?php echo esc_attr($s['chat_header_title'] ?? 'Questions? Chat with us.'); ?>"></td></tr>
                    <tr><th>Reply Time Text</th><td><input class="regular-text" name="<?php echo esc_attr($this->option); ?>[chat_reply_time_text]" value="<?php echo esc_attr($s['chat_reply_time_text'] ?? 'Typically replies under 41 minutes.'); ?>"></td></tr>
                    <tr><th>Chat Icon</th><td><input class="regular-text" name="<?php echo esc_attr($this->option); ?>[widget_icon]" value="<?php echo esc_attr($s['widget_icon'] ?? '💬'); ?>" maxlength="20"><p class="description">Use emoji or short text, for example: 💬, ☎, A, Help.</p></td></tr>
                    <tr><th>Icon Background Color</th><td><input type="color" name="<?php echo esc_attr($this->option); ?>[widget_icon_bg_color]" value="<?php echo esc_attr($s['widget_icon_bg_color'] ?? '#1266f1'); ?>"></td></tr>
                    <tr><th>Icon Text Color</th><td><input type="color" name="<?php echo esc_attr($this->option); ?>[widget_icon_text_color]" value="<?php echo esc_attr($s['widget_icon_text_color'] ?? '#ffffff'); ?>"></td></tr>
                </table>
                <?php submit_button('Save Settings'); ?>
            </form>
            <hr>
            <h2>Telegram Takeover Webhook</h2>
            <p>Required for Telegram replies/takeover messages to appear inside the website chat.</p>
            <?php if (!empty($s['telegram_bot_token'])): ?>
                <p><strong>Webhook URL:</strong></p>
                <input class="large-text" readonly value="<?php echo esc_attr($this->telegram_webhook_url($s)); ?>" onclick="this.select();">
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-top:10px">
                    <?php wp_nonce_field('mslc_set_telegram_webhook'); ?>
                    <input type="hidden" name="action" value="mslc_set_telegram_webhook">
                    <?php submit_button('Enable Telegram Takeover Webhook', 'secondary', 'submit', false); ?>
                </form>
                <p class="description">After clicking this, add your bot to a Telegram supergroup, make it admin, enable Topics, give Manage Topics permission, then send <code>/id</code> in that group. The plugin will auto-save the Group ID if the field is blank. Each website visitor will get a separate topic automatically.</p><p class="description"><strong>Important for multiple websites:</strong> one Telegram bot token can have only one active webhook URL. If the same bot token is saved on multiple WordPress sites, Telegram replies will work only on the last site where webhook was enabled. For reliable takeover on every website, use a separate BotFather bot token per website, or build one central webhook receiver.</p>
            <?php else: ?>
                <p class="description">Save your Telegram Bot Token first, then come back here to enable the takeover webhook.</p>
            <?php endif; ?>
            <hr>
            <h2>How to use</h2>
            <ol>
                <li>Create a Telegram bot with BotFather.</li>
                <li>Paste the Bot Token here and save settings.</li>
                <li>Click “Enable Telegram Takeover Webhook”.</li>
                <li>Add the bot to your Telegram supergroup and make it admin with Manage Topics permission.</li>
                <li>Enable Topics in the Telegram group settings.</li>
                <li>Send <code>/id</code> inside the group. The plugin will auto-save the Group ID if it is blank.</li>
                <li>When a visitor sends the first message, the plugin auto-creates a separate topic for that visitor.</li>
                <li>Reply inside that visitor topic; your message will appear in that visitor’s website chat.</li>
            </ol>
        </div>
        <?php
    }

    public function leads_page() {
        global $wpdb;
        $table = $wpdb->prefix . 'mslc_leads';
        $leads = $wpdb->get_results("SELECT * FROM $table ORDER BY id DESC LIMIT 100");
        echo '<div class="wrap"><h1>Chatbot Leads</h1><table class="widefat striped"><thead><tr><th>ID</th><th>Website</th><th>Name</th><th>Phone</th><th>Email</th><th>City</th><th>Service</th><th>Message</th><th>Date</th></tr></thead><tbody>';
        foreach ($leads as $l) {
            echo '<tr><td>'.esc_html($l->id).'</td><td>'.esc_html($l->website_name).'</td><td>'.esc_html($l->name).'</td><td>'.esc_html($l->phone).'</td><td>'.esc_html($l->email).'</td><td>'.esc_html($l->city).'</td><td>'.esc_html($l->service_type).'</td><td>'.esc_html(wp_trim_words($l->message, 12)).'</td><td>'.esc_html($l->created_at).'</td></tr>';
        }
        echo '</tbody></table></div>';
    }

    public function categories() {
        return [
            'sliding_door' => 'Sliding Door',
            'drywall' => 'Drywall',
            'christmas_lights' => 'Christmas / Govee Lights',
            'flooring' => 'Flooring',
            'cabinets' => 'Cabinets',
            'moving' => 'Moving',
            'appliance' => 'Appliance Repair',
            'painting' => 'Painting',
            'tv_mounting' => 'TV Mounting',
            'sprinkler' => 'Sprinkler',
            'hot_tub' => 'Hot Tub / Spa',
            'custom' => 'Custom / My Own Business'
        ];
    }

    private function custom_niche_keywords($s) {
        $raw = (string)($s['custom_niche_keywords'] ?? '');
        $parts = preg_split('/[\r\n,]+/', $raw);
        $parts = array_map(function($v) { return strtolower(trim($v)); }, $parts);
        return array_values(array_filter($parts, function($v) { return $v !== ''; }));
    }

    public function initial_buttons() {
        $s = $this->get_settings();
        $buttons = array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $s['initial_buttons'] ?? '')));
        return !empty($buttons) ? array_values($buttons) : ['Get Quote','Request Service','Talk To Human'];
    }

    public function service_buttons($category) {
        $map = [
            'sliding_door' => ['Sliding Door Repair','Track Repair','Roller Replacement','Get Quote'],
            'drywall' => ['Drywall Repair','Drywall Installation','Ceiling Repair','Get Quote'],
            'christmas_lights' => ['Installation','Removal','Permanent Lighting','Get Quote'],
            'flooring' => ['Epoxy Flooring','Garage Floor','Commercial Floor','Get Quote'],
            'cabinets' => ['Cabinet Installation','Cabinet Repair','Custom Cabinets','Get Quote'],
            'moving' => ['Local Move','Long Distance Move','Commercial Move','Get Quote'],
            'appliance' => ['Refrigerator Repair','Washer Repair','Dryer Repair','Dishwasher Repair','Get Quote'],
            'painting' => ['Interior Painting','Exterior Painting','Commercial Painting','Get Quote'],
            'tv_mounting' => ['TV Mounting','Sound Bar Installation','Wire Concealment','Get Quote'],
            'sprinkler' => ['Sprinkler Repair','Sprinkler Installation','Leak Detection','Get Quote'],
            'hot_tub' => ['Jacuzzi Maintenance','Hot Tub Pump Repair','Leaking Hot Tub Repair','Hot Tub Installation','Get Quote']
        ];
        $s = $this->get_settings();
        $custom = array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $s['service_buttons_custom'] ?? '')));
        if (!empty($custom)) return array_values($custom);
        if ($category === 'custom') return ['Get Quote'];
        return $map[$category] ?? $map['sliding_door'];
    }

    public function enqueue_assets() {
        $s = $this->get_settings();
        if ($s['widget_enabled'] !== '1') return;
        wp_enqueue_style('mslc-widget', plugin_dir_url(__FILE__) . 'assets/widget.css', [], '1.8.0');
        $bottom_padding = max(0, min(40, absint($s['chat_bottom_padding'] ?? 8)));
        $inline_css = ':root{--mslc-primary:' . esc_attr($s['widget_primary_color'] ?? '#1266f1') . ';--mslc-header:' . esc_attr($s['widget_header_color'] ?? '#1266f1') . ';--mslc-bot-bg:' . esc_attr($s['widget_bot_bubble_color'] ?? '#ffffff') . ';--mslc-user-bg:' . esc_attr($s['widget_user_bubble_color'] ?? '#1266f1') . ';--mslc-icon-bg:' . esc_attr($s['widget_icon_bg_color'] ?? '#1266f1') . ';--mslc-icon-color:' . esc_attr($s['widget_icon_text_color'] ?? '#ffffff') . ';--mslc-bottom-padding:' . $bottom_padding . 'px;}';
        wp_add_inline_style('mslc-widget', $inline_css);
        wp_enqueue_script('mslc-widget', plugin_dir_url(__FILE__) . 'assets/widget.js', ['jquery'], '1.8.0', true);
        wp_localize_script('mslc-widget', 'MSLC_DATA', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'rest_messages_url' => '',
            'nonce' => wp_create_nonce('mslc_nonce'),
            'site_id' => $s['site_id'],
            'website_name' => $s['website_name'],
            'category' => $s['category'],
            'buttons' => $this->service_buttons($s['category']),
            'initial_buttons' => $this->initial_buttons(),
            'widget_icon' => $s['widget_icon'] ?? '💬',
            'admin_avatar_url' => esc_url($s['admin_avatar_url'] ?? ''),
            'chat_header_title' => $s['chat_header_title'] ?? 'Questions? Chat with us.',
            'chat_reply_time_text' => $s['chat_reply_time_text'] ?? 'Typically replies under 41 minutes.'
        ]);
    }

    public function render_widget() {
        $s = $this->get_settings();
        if ($s['widget_enabled'] !== '1') return;
        echo '<div id="mslc-chat-root"></div>';
    }

    private function client_ip() {
        $keys = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'];
        foreach ($keys as $key) {
            if (empty($_SERVER[$key])) continue;
            $raw = sanitize_text_field(wp_unslash($_SERVER[$key]));
            $ip = trim(explode(',', $raw)[0]);
            if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
        }
        return 'unknown';
    }

    private function rate_limit($action, $limit, $window = 60) {
        $ip = $this->client_ip();
        $key = 'mslc_rl_' . md5($action . '|' . $ip);
        $count = intval(get_transient($key));
        if ($count >= $limit) {
            wp_send_json_error(['message' => 'Too many requests. Please wait a moment and try again.'], 429);
        }
        set_transient($key, $count + 1, $window);
    }

    private function validate_frontend_session($session) {
        return is_string($session) && preg_match('/^chat_[0-9]{8,}_[A-Za-z0-9]{6,20}$/', $session);
    }

    private function session_client_token_key($session) {
        return 'mslc_client_token_' . md5((string)$session);
    }

    private function store_session_client_token($session, $token) {
        $token = sanitize_text_field((string)$token);
        if (!$this->validate_frontend_session($session) || strlen($token) < 16 || strlen($token) > 128) return false;
        set_transient($this->session_client_token_key($session), wp_hash($token), 7 * DAY_IN_SECONDS);
        return true;
    }

    private function validate_session_client_token($session, $token) {
        $token = sanitize_text_field((string)$token);
        if (!$this->validate_frontend_session($session) || strlen($token) < 16) return false;
        $saved = get_transient($this->session_client_token_key($session));
        return !empty($saved) && hash_equals((string)$saved, wp_hash($token));
    }

    private function validate_frontend_request($session) {
        $nonce_ok = check_ajax_referer('mslc_nonce', 'nonce', false);
        if ($nonce_ok) return true;
        $client_token = sanitize_text_field($_POST['client_token'] ?? '');
        if ($this->validate_session_client_token($session, $client_token)) return true;
        wp_send_json_error(['message' => 'Security check failed. Please refresh the page and try again.'], 403);
    }

    public function ajax_start_chat() {
        // Public widget support: cached pages can contain an expired WP nonce after many hours/days.
        // Do not fail start_chat for that case; the per-session client token below protects later AJAX calls.
        check_ajax_referer('mslc_nonce', 'nonce', false);
        $this->rate_limit('start_chat', 20, 60);
        $session = sanitize_text_field($_POST['session'] ?? '');
        $s = $this->get_settings();

        if ($session === '') {
            $session = 'chat_' . time() . '_' . wp_generate_password(8, false, false);
        }
        if (!$this->validate_frontend_session($session)) {
            wp_send_json_error(['message' => 'Invalid chat session.'], 400);
        }
        $this->store_session_client_token($session, sanitize_text_field($_POST['client_token'] ?? ''));

        $this->ensure_session_meta($session);
        $greeting = 'How can I help you?';
        $this->save_chat($s['site_id'], $session, 'bot', $greeting);
        // Do not notify Telegram for the first auto greeting. Telegram starts only after visitor replies.

        wp_send_json_success(['session' => $session, 'text' => $greeting]);
    }


    private function handle_frontend_attachment() {
        if (empty($_FILES['attachment']) || empty($_FILES['attachment']['name'])) return '';
        $file = $_FILES['attachment'];
        if (!empty($file['error'])) return '';
        if (!empty($file['size']) && (int)$file['size'] > 5 * 1024 * 1024) {
            wp_send_json_error(['message' => 'Attachment is too large. Maximum size is 5MB.'], 400);
        }
        $allowed = [
            'image/jpeg','image/png','image/gif','image/webp','image/avif','image/x-avif',
            'application/pdf','text/plain','text/csv','application/csv',
            'application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'application/vnd.ms-powerpoint','application/vnd.openxmlformats-officedocument.presentationml.presentation',
            'application/rtf','application/zip','application/x-zip-compressed'
        ];
        $type = !empty($file['type']) ? $file['type'] : '';
        $ext = strtolower(pathinfo($file['name'] ?? '', PATHINFO_EXTENSION));
        $allowed_ext = ['jpg','jpeg','png','gif','webp','avif','pdf','doc','docx','xls','xlsx','csv','txt','rtf','ppt','pptx','zip'];
        if (($type && !in_array($type, $allowed, true)) && !in_array($ext, $allowed_ext, true)) {
            wp_send_json_error(['message' => 'Only images including AVIF, PDF, DOC, CSV, Excel, PowerPoint, ZIP, or text files are allowed.'], 400);
        }
        if (!function_exists('wp_handle_upload')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        $uploaded = wp_handle_upload($file, ['test_form' => false]);
        if (!empty($uploaded['error'])) {
            wp_send_json_error(['message' => 'Attachment upload failed: ' . $uploaded['error']], 400);
        }
        return esc_url_raw($uploaded['url'] ?? '');
    }

    public function ajax_send_message() {
        $this->rate_limit('send_message', 35, 60);
        $msg = sanitize_textarea_field($_POST['message'] ?? '');
        $session = sanitize_text_field($_POST['session'] ?? '');
        $s = $this->get_settings();
        $this->validate_frontend_request($session);

        if ($session === '') {
            $session = 'chat_' . time() . '_' . wp_generate_password(8, false, false);
        }
        if (!$this->validate_frontend_session($session)) {
            wp_send_json_error(['message' => 'Invalid chat session.'], 400);
        }
        $attachment_url = $this->handle_frontend_attachment();
        if ($msg === '' && empty($attachment_url)) {
            wp_send_json_error(['message' => 'Please type a message.']);
        }
        if (strlen($msg) > 1000) {
            wp_send_json_error(['message' => 'Message too long.'], 400);
        }
        if (!empty($attachment_url)) {
            $msg = trim($msg . "
Attachment: " . $attachment_url);
        }

        $this->save_chat($s['site_id'], $session, 'visitor', $msg);

        // If a Telegram admin has taken over, do not append visitor text to the old bot transcript.
        // Send it as a fresh Telegram message so live chats stay easier to manage.
        if ($this->is_session_taken($session)) {
            $this->send_telegram_takeover_visitor_message($session, $msg);
            wp_send_json_success(['text' => '', 'session' => $session, 'human' => true]);
        }

        $this->send_telegram_chat_update($session, 'Visitor', $msg);

        // Admin Active Mode: when a human admin is online, do not run the AI lead questions.
        // The visitor's first message creates/updates a Telegram topic and the admin can take over from there.
        if ($this->is_admin_live_mode($s)) {
            // Admin is online from Telegram /online command. Keep AI fully silent on the website.
            // The visitor message has already been sent to Telegram above, so admin can takeover and reply directly.
            wp_send_json_success(['text' => '', 'session' => $session, 'admin_live' => true]);
        }

        $reply = $this->human_rule_reply($session, $msg, $s);
        if (!empty($reply['text'])) {
            $this->save_chat($s['site_id'], $session, 'bot', $reply['text']);
            $this->send_telegram_chat_update($session, 'Bot', $reply['text']);
        }

        if (!empty($reply['lead_ready'])) {
            $lead_id = $this->create_lead_from_chat($session, $reply['state'], $msg);
            if ($lead_id) {
                $lead = [
                    'website_name' => $s['website_name'],
                    'visitor_session' => $session,
                    'service_type' => $reply['state']['service_type'] ?? '',
                    'name' => $reply['state']['name'] ?? '',
                    'phone' => $reply['state']['phone'] ?? '',
                    'email' => $reply['state']['email'] ?? '',
                    'city' => $reply['state']['city'] ?? '',
                    'message' => $reply['state']['first_message'] ?? $msg
                ];
                $this->send_telegram_lead($lead_id, $lead);
            }
        }

        wp_send_json_success(['text' => $reply['text'] ?? '', 'session' => $session]);
    }

    public function ajax_submit_lead() {
        $this->rate_limit('submit_lead', 8, 60);
        global $wpdb;
        $s = $this->get_settings();
        $table = $wpdb->prefix . 'mslc_leads';
        $session = sanitize_text_field($_POST['session'] ?? '');
        $this->validate_frontend_request($session);
        $lead_message = sanitize_textarea_field($_POST['message'] ?? '');
        if ($session !== '' && !$this->validate_frontend_session($session)) {
            wp_send_json_error(['message' => 'Invalid chat session.'], 400);
        }
        if (strlen($lead_message) > 1000) {
            wp_send_json_error(['message' => 'Message too long.'], 400);
        }
        $data = [
            'site_id' => $s['site_id'],
            'website_name' => $s['website_name'],
            'category' => $s['category'],
            'visitor_session' => $session,
            'service_type' => sanitize_text_field($_POST['service_type'] ?? ''),
            'name' => sanitize_text_field($_POST['name'] ?? ''),
            'phone' => sanitize_text_field($_POST['phone'] ?? ''),
            'email' => sanitize_email($_POST['email'] ?? ''),
            'city' => sanitize_text_field($_POST['city'] ?? ''),
            'message' => $lead_message,
            'extra_data' => wp_json_encode(['source' => 'frontend_form'])
        ];

        $inserted = $wpdb->insert($table, $data);
        if (!$inserted) {
            wp_send_json_error(['message' => 'Lead could not be saved in WordPress database.']);
        }

        $lead_id = $wpdb->insert_id;
        $telegram = $this->send_telegram_lead($lead_id, $data);

        if (is_wp_error($telegram)) {
            wp_send_json_error(['message' => 'Lead saved, but Telegram failed: ' . $telegram->get_error_message()]);
        }

        wp_send_json_success(['message' => 'Thank you! Your request has been submitted.', 'session' => $data['visitor_session']]);
    }

    private function is_admin_live_mode($s = null) {
        $s = $s ?: $this->get_settings();
        return !empty($s['admin_live_mode']) && (string)$s['admin_live_mode'] === '1';
    }

    private function set_admin_live_mode($enabled) {
        $settings = get_option($this->option, []);
        if (!is_array($settings)) $settings = [];
        $settings['admin_live_mode'] = $enabled ? '1' : '0';
        update_option($this->option, wp_parse_args($settings, $this->defaults()));
        return true;
    }

    private function admin_live_waiting_reply($session) {
        return '';
    }

    private function human_rule_reply($session, $msg, $s) {
        $key = 'mslc_chat_state_' . md5($session);
        $state = get_transient($key);
        if (!is_array($state)) {
            $state = $this->default_chat_state($msg);
        } else {
            $state = wp_parse_args($state, $this->default_chat_state(''));
        }

        $clean = trim($msg);
        if (empty($state['first_message'])) {
            $state['first_message'] = $clean;
        } elseif ($clean !== '' && strpos((string)$state['first_message'], $clean) === false) {
            $state['first_message'] = $this->append_lead_message($state['first_message'], $clean);
        }

        // First read every visitor message and merge any details already provided.
        // The bot should never ask again for name/phone/email/city/service once detected.
        $state = $this->merge_lead_info_from_message($state, $clean, $s, $session);

        $scope_warning = $this->service_scope_warning($clean, $s);
        if ($scope_warning !== '') {
            set_transient($key, $state, 7 * DAY_IN_SECONDS);
            return ['text' => $scope_warning, 'state' => $state];
        }

        if (!empty($state['lead_sent'])) {
            $answer = $this->contextual_answer($clean, $state, $s);
            if ($answer === '') $answer = 'Thanks, I’ll pass this update to our expert.';
            set_transient($key, $state, 7 * DAY_IN_SECONDS);
            return ['text' => $answer, 'state' => $state];
        }

        if ($this->is_email_decline($clean) && ($state['stage'] ?? '') === 'collect_email') {
            $state['email_declined'] = 1;
        }

        $answer = $this->contextual_answer($clean, $state, $s);

        // Required lead fields: name, phone, service type, and service area/city.
        // Email is collected politely at the end as a newsletter/update option.
        if ($this->has_required_lead_details($state)) {
            if (empty($state['email']) && empty($state['email_declined']) && intval($state['email_ask_count'] ?? 0) < 1) {
                $state['stage'] = 'collect_email';
                $state['email_ask_count'] = intval($state['email_ask_count'] ?? 0) + 1;
                set_transient($key, $state, 7 * DAY_IN_SECONDS);
                return ['text' => trim($answer . ' ' . $this->email_ask_reply($state)), 'state' => $state];
            }

            $state['stage'] = 'ready';
            $state['lead_sent'] = 1;
            set_transient($key, $state, 7 * DAY_IN_SECONDS);
            $lead_answer = in_array($answer, ['Got it.', 'Hi.', 'You are welcome.'], true) ? '' : $answer;
            return ['text' => trim($lead_answer . ' ' . $this->lead_confirmation_reply($state)), 'state' => $state, 'lead_ready' => true];
        }

        $ask = $this->next_missing_detail_question($state, $s, $clean);
        set_transient($key, $state, 7 * DAY_IN_SECONDS);

        return ['text' => trim($answer . ' ' . $ask), 'state' => $state];
    }

    private function default_chat_state($first_message = '') {
        return [
            'stage' => 'need_name',
            'first_message' => trim((string)$first_message),
            'name' => '',
            'phone' => '',
            'email' => '',
            'city' => '',
            'service_type' => '',
            'lead_sent' => 0,
            'email_declined' => 0,
            'phone_ask_count' => 0,
            'name_ask_count' => 0,
            'service_ask_count' => 0,
            'city_ask_count' => 0,
            'email_ask_count' => 0
        ];
    }

    private function has_required_lead_details($state) {
        return !empty($state['name']) && !empty($state['phone']) && !empty($state['service_type']) && !empty($state['city']);
    }

    private function next_missing_detail_question(&$state, $s, $last_message = '') {
        $last_message = (string)$last_message;

        // If visitor is asking for the services list and has not chosen one yet, answer services first.
        if (empty($state['service_type']) && $this->is_services_list_question($last_message)) {
            $state['stage'] = 'collect_service';
            $state['service_ask_count'] = intval($state['service_ask_count'] ?? 0) + 1;
            return 'Which service do you need help with?';
        }

        if (empty($state['name'])) {
            $state['stage'] = 'need_name';
            $state['name_ask_count'] = intval($state['name_ask_count'] ?? 0) + 1;
            return $this->name_ask_reply($state);
        }

        if (empty($state['service_type'])) {
            $state['stage'] = 'collect_service';
            $state['service_ask_count'] = intval($state['service_ask_count'] ?? 0) + 1;
            return $this->service_ask_reply($state, $s);
        }

        if (empty($state['phone'])) {
            $state['stage'] = 'collect_phone';
            $state['phone_ask_count'] = intval($state['phone_ask_count'] ?? 0) + 1;
            return $this->phone_ask_reply($state);
        }

        if (empty($state['city'])) {
            $state['stage'] = 'collect_city';
            $state['city_ask_count'] = intval($state['city_ask_count'] ?? 0) + 1;
            return $this->city_ask_reply($state);
        }

        if (empty($state['email']) && empty($state['email_declined'])) {
            $state['stage'] = 'collect_email';
            $state['email_ask_count'] = intval($state['email_ask_count'] ?? 0) + 1;
            return $this->email_ask_reply($state);
        }

        return '';
    }

    private function contextual_answer($msg, $state, $s) {
        $msg = trim((string)$msg);
        if ($msg === '') return '';

        $parts = [];

        if ($this->is_services_list_question($msg)) {
            $parts[] = 'We provide ' . $this->allowed_services_text($s) . '.';
        } elseif ($this->is_area_question($msg)) {
            $parts[] = 'Yes, we provide service across the USA.';
        } elseif ($this->is_allowed_service_question($msg, $s) || (!empty($state['service_type']) && preg_match('/\b(available|do\s+you\s+provide|can\s+you\s+help|offer)\b/i', $msg))) {
            $service = !empty($state['service_type']) ? $state['service_type'] : 'that service';
            $parts[] = ($service === 'Service Request') ? 'Yes, we can help with that.' : 'Yes, ' . $service . ' is available.';
        }

        if (empty($parts)) {
            $matched = $this->match_custom_rule($msg, $s['conversation_rules'] ?? '');
            if ($matched !== '') {
                $matched = $this->remove_name_request_phrases($matched);
                $matched = trim($matched);
                if ($matched !== '') $parts[] = $matched;
            }
        }

        if (empty($parts)) {
            if (preg_match('/\b(price|cost|quote|estimate|how much)\b/i', $msg)) $parts[] = 'I can get that checked for you.';
            elseif (preg_match('/\b(available|today|tomorrow|schedule|appointment)\b/i', $msg)) $parts[] = 'Yes, we can check the earliest available slot for you.';
            elseif (preg_match('/\b(thanks|thank you|ok|okay)\b/i', $msg)) $parts[] = 'You are welcome.';
            elseif (preg_match('/\b(hi|hello|hey|salam|assalam|good\s*(morning|afternoon|evening))\b/i', $msg)) $parts[] = 'Hi.';
            else $parts[] = 'Got it.';
        }

        $text = trim(implode(' ', array_filter($parts)));
        $text = preg_replace('/\s+/', ' ', $text);
        return $text;
    }

    private function reply_already_covered($reply, $parts) {
        $reply_l = strtolower(trim((string)$reply));
        foreach ((array)$parts as $part) {
            if (strtolower(trim((string)$part)) === $reply_l) return true;
        }
        return false;
    }

    private function is_services_list_question($msg) {
        $msg = strtolower((string)$msg);
        return (bool) preg_match('/\b(what|which|list|tell\s+me|show\s+me)\b.*\b(service|services)\b|\b(service|services)\b.*\b(provide|offer|available|do\s+you\s+do)\b/i', $msg);
    }

    private function is_area_question($msg) {
        $msg = strtolower((string)$msg);
        return (bool) preg_match('/\b(service\s+area|areas?\s+do\s+you\s+serve|do\s+you\s+serve|do\s+you\s+provide\s+service\s+(in|near|around)|available\s+(in|near|around)|serve\s+(in|near|around)|near\s+me|location|city)\b/i', $msg);
    }

    private function is_allowed_service_question($msg, $s) {
        $msg_l = strtolower((string)$msg);
        if (!preg_match('/\b(available|do\s+you\s+provide|do\s+you\s+offer|can\s+you\s+help|need|want|looking|service|repair|install|installation|quote|estimate)\b/i', $msg_l)) return false;
        foreach ($this->allowed_service_names($s) as $service) {
            $service_l = strtolower($service);
            if ($service_l !== '' && strpos($msg_l, $service_l) !== false) return true;
            foreach (array_filter(preg_split('/\s+/', $service_l)) as $word) {
                if (strlen($word) > 3 && strpos($msg_l, $word) !== false) return true;
            }
        }
        return !empty($this->extract_service_type($msg, $s));
    }

    private function is_email_decline($msg) {
        return (bool) preg_match('/\b(no|nope|not\s+now|skip|later|don\'?t\s+have|do\s+not\s+have|without\s+email|no\s+email)\b/i', (string)$msg);
    }

    private function append_lead_message($current, $new) {
        $current = trim((string)$current);
        $new = trim((string)$new);
        if ($new === '') return $current;
        $combined = trim($current === '' ? $new : $current . ' ' . $new);
        return strlen($combined) > 1200 ? substr($combined, 0, 1200) : $combined;
    }

    private function merge_lead_info_from_message($state, $text, $s, $session = '') {
        $text = trim((string)$text);
        if ($text === '') return $state;

        if (empty($state['name'])) {
            $detected_name = $this->extract_visitor_name($text);
            if ($detected_name !== '') {
                $state['name'] = $detected_name;
                if ($session !== '') $this->update_session_visitor_name($session, $state['name']);
            }
        }

        if (empty($state['phone'])) {
            $phone = $this->extract_phone($text);
            if ($phone !== '') $state['phone'] = $phone;
        }

        if (empty($state['email'])) {
            $email = $this->extract_email($text);
            if ($email !== '') $state['email'] = $email;
        }

        if (empty($state['city'])) {
            $city = $this->extract_city($text);
            if ($city === '' && ($state['stage'] ?? '') === 'collect_city') {
                $city = $this->extract_standalone_city($text);
            }
            if ($city !== '') $state['city'] = $city;
        }

        if (empty($state['service_type'])) {
            $service_type = $this->extract_service_type($text, $s);
            if ($service_type !== '') $state['service_type'] = $service_type;
        }

        return $state;
    }

    private function lead_confirmation_reply($state) {
        $name = trim($state['name'] ?? '');
        $prefix = $name !== '' && strtolower($name) !== 'visitor' ? 'Thanks ' . $name . ', ' : 'Thanks, ';
        return $prefix . 'I’ve received your details. Our expert will contact you soon.';
    }

    private function allowed_service_names($s) {
        $services = $this->service_buttons($s['category'] ?? '');
        $services = array_filter(array_map('trim', $services), function($v) {
            return $v !== '' && !preg_match('/^(get quote|request service|talk to human)$/i', $v);
        });
        return array_values($services);
    }

    private function allowed_services_text($s) {
        $services = $this->allowed_service_names($s);
        if (empty($services)) return 'our listed services';
        return implode(', ', $services);
    }

    private function out_of_scope_reply($s) {
        return 'Sorry, we don’t provide that service. We can help with ' . $this->allowed_services_text($s) . '. If you need any of these services, I’ll be happy to take your details.';
    }

    private function service_scope_warning($msg, $s) {
        $msg_l = strtolower(trim((string)$msg));
        if ($msg_l === '') return '';

        // Asking for the services list is not an out-of-scope request.
        if ($this->is_services_list_question($msg_l)) return '';

        // If the visitor mentions an allowed service from backend settings, allow it immediately.
        foreach ($this->allowed_service_names($s) as $allowed) {
            $allowed_l = strtolower($allowed);
            if ($allowed_l !== '' && strpos($msg_l, $allowed_l) !== false) return '';
            foreach (array_filter(preg_split('/\s+/', $allowed_l)) as $word) {
                if (strlen($word) > 4 && strpos($msg_l, $word) !== false) return '';
            }
        }

        $category = $s['category'] ?? '';
        $service_keywords = $this->service_keyword_map($s);

        $matched_categories = [];
        foreach ($service_keywords as $cat => $keywords) {
            foreach ($keywords as $kw) {
                if ($kw !== '' && strpos($msg_l, $kw) !== false) {
                    $matched_categories[$cat] = true;
                    break;
                }
            }
        }

        if (empty($matched_categories)) return '';
        if (isset($matched_categories[$category])) return '';

        return $this->out_of_scope_reply($s);
    }

    private function service_keyword_map($s = null) {
        $map = [
            'sliding_door' => ['sliding door','patio door','door track','track repair','roller','roller replacement','glass door'],
            'drywall' => ['drywall','sheetrock','ceiling repair','wall repair','hole repair','patch'],
            'christmas_lights' => ['christmas light','christmas lights','holiday light','holiday lights','govee','permanent light','outdoor lights'],
            'flooring' => ['epoxy','epoxy flooring','garage floor','garage flooring','commercial floor','floor coating','flooring'],
            'cabinets' => ['cabinet','cabinets','custom cabinet','carpentry'],
            'moving' => ['moving','mover','move','relocation','local move','long distance','commercial move'],
            'appliance' => ['appliance','refrigerator','fridge','washer','dryer','dishwasher','oven'],
            'painting' => ['painting','paint','interior paint','exterior paint'],
            'tv_mounting' => ['tv mounting','tv mount','mount tv','sound bar','wire concealment'],
            'sprinkler' => ['sprinkler','irrigation','sprinkler repair','sprinkler installation','leak detection'],
            'hot_tub' => ['hot tub','jacuzzi','spa repair','pump repair','leaking hot tub'],
            'other' => ['plumbing','plumber','roofing','roofer','hvac','air conditioning','electrician','electrical','cleaning','house cleaning','carpet cleaning','landscaping','lawn care','pest control','locksmith','garage door','pool cleaning','window cleaning']
        ];
        if ($s === null) $s = $this->get_settings();
        $custom_keywords = $this->custom_niche_keywords($s);
        if (!empty($custom_keywords)) $map['custom'] = $custom_keywords;
        return $map;
    }

    private function smart_answer_without_phone($clean, $s) {
        $matched = $this->match_custom_rule($clean, $s['conversation_rules'] ?? '');
        if ($matched !== '') return $matched;

        // Read the visitor's intent before a greeting, so messages like
        // "hello I'm George and I want service" do not get treated as only a greeting.
        if (preg_match('/\b(service|repair|install|installation|fix|move|moving|quote|estimate|appointment|schedule)\b/i', $clean)) return 'Sure, we can help with that.';
        if (preg_match('/\b(price|cost|how much)\b/i', $clean)) return 'I can get that checked for you.';
        if (preg_match('/\b(available|today|tomorrow)\b/i', $clean)) return 'Yes, we can check availability.';
        if (preg_match('/\b(where|location|area|near me)\b/i', $clean)) return 'We can check your area.';
        if (preg_match('/\b(hi|hello|hey|salam|assalam|good\s*(morning|afternoon|evening))\b/i', $clean)) return 'Hi.';
        if (preg_match('/\b(thanks|thank you|ok|okay)\b/i', $clean)) return 'No problem.';
        return 'Got it.';
    }

    private function remove_name_request_phrases($text) {
        $text = (string)$text;
        $patterns = [
            '/\bmay\s+i\s+have\s+your\s+name\??/i',
            '/\bcan\s+i\s+get\s+your\s+name\??/i',
            '/\bwhat\s+is\s+your\s+name\??/i',
            '/\bplease\s+share\s+your\s+name\.?/i'
        ];
        $text = preg_replace($patterns, '', $text);
        return trim(preg_replace('/\s+/', ' ', $text));
    }

    private function phone_ask_reply($state) {
        $name = trim($state['name'] ?? '');
        $variants = [
            'Can I get your phone number so our expert can reach you?',
            'What number should our expert contact you on?',
            'Please send your best contact number and I’ll pass it to our expert.',
            'Could you share your phone number? Our expert will contact you shortly.',
            'Send me your number please, then I’ll have our expert follow up.'
        ];
        $i = max(0, intval($state['phone_ask_count'] ?? 0) - 1) % count($variants);
        $prefix = $name !== '' && strtolower($name) !== 'visitor' ? 'Hi ' . $name . ', ' : 'Hi, ';
        return $prefix . lcfirst($variants[$i]);
    }

    private function name_ask_reply($state) {
        $variants = [
            'May I have your name?',
            'Sure, what name should I put this under?',
            'Got it, can I get your name please?',
            'Okay, may I know your name?',
            'Thanks, who am I speaking with?'
        ];
        $i = max(0, intval($state['name_ask_count'] ?? 0) - 1) % count($variants);
        return $variants[$i];
    }

    private function service_ask_reply($state, $s) {
        $services = $this->allowed_services_text($s);
        $variants = [
            'Which service do you need help with? We provide ' . $services . '.',
            'What service are you looking for today? Our services include ' . $services . '.',
            'Please tell me which service you need, and I’ll guide you from there.'
        ];
        $i = max(0, intval($state['service_ask_count'] ?? 0) - 1) % count($variants);
        return $variants[$i];
    }

    private function city_ask_reply($state) {
        $variants = [
            'What city or service area do you need help in?',
            'Which city should our expert check for service?',
            'Please share your service area so we can route this correctly.'
        ];
        $i = max(0, intval($state['city_ask_count'] ?? 0) - 1) % count($variants);
        return $variants[$i];
    }

    private function email_ask_reply($state) {
        $name = trim($state['name'] ?? '');
        if ($name !== '' && strtolower($name) !== 'visitor') {
            return 'Great, ' . $name . '. Could you share your email so we can keep you updated?';
        }
        return 'Great. Could you share your email so we can keep you updated?';
    }

    private function extract_email($text) {
        if (preg_match('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i', (string)$text, $m)) {
            $email = sanitize_email($m[0]);
            return is_email($email) ? $email : '';
        }
        return '';
    }

    private function extract_city($text) {
        $text = trim(wp_strip_all_tags((string)$text));
        if ($text === '') return '';
        $safe = preg_replace('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i', ' ', $text);
        $safe = preg_replace('/\+?\d[\d\s\-\(\)]{6,}\d/', ' ', $safe);
        $safe = $this->normalize_lead_text($safe);

        $patterns = [
            '/\b(?:city|area|location|service\s+area)\s*(?:is|=|:)?\s+([a-zA-Z][a-zA-Z\s\.\-\']{1,70})/i',
            '/\b(?:in|near|around|from|at)\s+([a-zA-Z][a-zA-Z\s\.\-\']{1,70})/i',
            '/\b(?:serve|service|available)\s+(?:in|near|around)\s+([a-zA-Z][a-zA-Z\s\.\-\']{1,70})/i',
            '/\b(?:do\s+you\s+serve|do\s+you\s+provide\s+service\s+in|can\s+you\s+come\s+to)\s+([a-zA-Z][a-zA-Z\s\.\-\']{1,70})/i'
        ];

        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $safe, $m)) {
                $city = $this->clean_city($m[1]);
                if ($city !== '') return $city;
            }
        }
        return '';
    }

    private function extract_standalone_city($text) {
        $text = $this->normalize_lead_text($text);
        if ($text === '') return '';
        if (preg_match('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i', $text)) return '';
        if (preg_match('/\+?\d[\d\s\-\(\)]{6,}\d/', $text)) return '';
        if (preg_match('/\b(service|services|repair|install|installation|quote|price|cost|available|phone|number|email|mail|name|hi|hello|hey|thanks|thank|yes|no|ok|okay)\b/i', $text)) return '';
        if (str_word_count($text) > 4) return '';
        return $this->clean_city($text);
    }

    private function clean_city($city) {
        $city = trim((string)$city);
        $city = preg_split('/[,.!?;:]|\b(?:and|but|for|my|phone|number|email|mail|service|services|repair|install|installation|need|want|looking|please|thanks|thank|from|to|with|about|can|could|tell|which|what|do|does|is|are|available|provide|offer)\b/i', $city)[0];
        $city = preg_replace('/[^a-zA-Z\s\.\-\']/', '', $city);
        $city = trim(preg_replace('/\s+/', ' ', $city));
        if ($city === '') return '';
        if (preg_match('/\b(your|company|business|website|site|team|expert|person|someone|home|house|office|address|service|services|near|me)\b/i', $city)) return '';
        if (strlen($city) < 2 || strlen($city) > 60) return '';
        return ucwords(strtolower($city));
    }

    private function extract_service_type($text, $s) {
        $msg_l = strtolower((string)$text);
        if ($msg_l === '') return '';

        // Do not treat "which services do you provide" as the visitor choosing a service.
        if ($this->is_services_list_question($msg_l)) return '';

        foreach ($this->allowed_service_names($s) as $service) {
            $service_l = strtolower($service);
            if ($service_l !== '' && strpos($msg_l, $service_l) !== false) return $service;
            $words = array_filter(preg_split('/\s+/', $service_l));
            $hit = 0;
            foreach ($words as $word) {
                if (strlen($word) > 3 && strpos($msg_l, $word) !== false) $hit++;
            }
            if ($hit >= max(1, min(2, count($words)))) return $service;
        }

        $category = $s['category'] ?? '';
        $category_labels = [
            'sliding_door' => ['Sliding Door Repair' => ['sliding door','patio door','roller','track repair','glass door']],
            'drywall' => ['Drywall Repair' => ['drywall','sheetrock','ceiling repair','wall repair','hole repair','patch']],
            'christmas_lights' => ['Christmas Light Installation' => ['christmas light','holiday light','govee','permanent light','outdoor lights']],
            'flooring' => ['Epoxy Flooring' => ['epoxy','garage floor','floor coating','flooring','floor']],
            'cabinets' => ['Cabinet Service' => ['cabinet','cabinets','carpentry']],
            'moving' => ['Moving Service' => ['moving','mover','move','relocation','local move','long distance','commercial move']],
            'appliance' => ['Appliance Repair' => ['appliance','refrigerator','fridge','washer','dryer','dishwasher','oven']],
            'painting' => ['Painting Service' => ['painting','paint','interior paint','exterior paint']],
            'tv_mounting' => ['TV Mounting' => ['tv mounting','tv mount','mount tv','sound bar','wire concealment']],
            'sprinkler' => ['Sprinkler Service' => ['sprinkler','irrigation','leak detection']],
            'hot_tub' => ['Hot Tub Repair' => ['hot tub','jacuzzi','spa repair','pump repair','leaking hot tub']]
        ];

        $custom_keywords = $this->custom_niche_keywords($s);
        if ($category === 'custom' && !empty($custom_keywords)) {
            $custom_label = !empty($s['custom_niche_name']) ? trim($s['custom_niche_name']) . ' Service' : 'Service Request';
            $category_labels['custom'] = [$custom_label => $custom_keywords];
        }

        if (!empty($category_labels[$category])) {
            foreach ($category_labels[$category] as $label => $keywords) {
                foreach ($keywords as $kw) {
                    if ($kw !== '' && strpos($msg_l, $kw) !== false) return $label;
                }
            }
        }

        if (preg_match('/\b(?:need|want|looking\s+for|book|schedule|get|request)\b.{0,35}\b(service|quote|estimate|appointment)\b/i', $msg_l)) {
            return 'Service Request';
        }
        if ($this->is_area_question($msg_l) && preg_match('/\b(service|serve|available|provide)\b/i', $msg_l)) {
            return 'Service Request';
        }
        return '';
    }

    private function normalize_lead_text($text) {
        $text = wp_strip_all_tags((string)$text);
        $text = str_replace(["\xE2\x80\x99", "\xE2\x80\x98", "\xE2\x80\x9B", "\xE2\x80\xB2", '`', '´', '’', '‘', '‛', '′'], "'", $text);
        $text = str_replace(["\xE2\x80\x9C", "\xE2\x80\x9D", '“', '”'], '"', $text);
        $text = $this->normalize_user_shortcuts($text);
        $text = preg_replace('/\s+/', ' ', $text);
        return trim($text);
    }

    private function normalize_user_shortcuts($text) {
        $text = (string)$text;
        if ($text === '') return '';

        // Keep emails safe while normalizing casual chat shortcuts.
        $emails = [];
        $text = preg_replace_callback('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i', function($m) use (&$emails) {
            $key = ' __MSLC_EMAIL_' . count($emails) . '__ ';
            $emails[$key] = $m[0];
            return $key;
        }, $text);

        $phrase_replacements = [
            '/\bi\s*[\'’`]?\s*m\b/i' => 'i am',
            '/\bi\s*m\b/i' => 'i am',
            '/\biam\b/i' => 'i am',
            '/\bi\s*wanna\b/i' => 'i want to',
            '/\bwanna\b/i' => 'want to',
            '/\bgonna\b/i' => 'going to',
            '/\bgotta\b/i' => 'have to',
            '/\bdon[\'’`]?t\b/i' => 'do not',
            '/\bdoesn[\'’`]?t\b/i' => 'does not',
            '/\bcan[\'’`]?t\b/i' => 'cannot',
            '/\bwon[\'’`]?t\b/i' => 'will not',
            '/\bu\s+r\b/i' => 'you are'
        ];
        foreach ($phrase_replacements as $pattern => $replacement) {
            $text = preg_replace($pattern, $replacement, $text);
        }

        $word_replacements = [
            'hlo' => 'hello', 'helo' => 'hello', 'hellow' => 'hello', 'hlw' => 'hello', 'heyya' => 'hello',
            'hy' => 'hi', 'hai' => 'hi', 'hiya' => 'hi',
            'plz' => 'please', 'pls' => 'please', 'plss' => 'please',
            'thx' => 'thanks', 'thanx' => 'thanks', 'tnx' => 'thanks', 'ty' => 'thank you',
            'svc' => 'service', 'srvc' => 'service', 'servce' => 'service', 'servis' => 'service', 'srvce' => 'service',
            'req' => 'request', 'rqst' => 'request', 'appt' => 'appointment', 'apt' => 'appointment',
            'num' => 'number', 'nmbr' => 'number', 'nbr' => 'number', 'no' => 'number',
            'ph' => 'phone', 'fone' => 'phone', 'mob' => 'mobile', 'cell' => 'phone',
            'mail' => 'email', 'eml' => 'email',
            'addr' => 'address', 'addrs' => 'address', 'loc' => 'location', 'cty' => 'city',
            'info' => 'information', 'msg' => 'message', 'prob' => 'problem', 'prblm' => 'problem',
            'asap' => 'as soon as possible', 'tmrw' => 'tomorrow', 'tdy' => 'today',
            'quotee' => 'quote', 'quot' => 'quote', 'est' => 'estimate',
            'instal' => 'install', 'instll' => 'install', 'installationn' => 'installation',
            'repairr' => 'repair', 'fixx' => 'fix',
            'la' => 'Los Angeles', 'nyc' => 'New York City'
        ];
        foreach ($word_replacements as $short => $full) {
            $text = preg_replace('/\b' . preg_quote($short, '/') . '\b/i', $full, $text);
        }

        // Common compact forms like "needsvc" or "need srvc" from fast mobile typing.
        $text = preg_replace('/\bneedsvc\b/i', 'need service', $text);
        $text = preg_replace('/\bwantsvc\b/i', 'want service', $text);
        $text = preg_replace('/\bneedquote\b/i', 'need quote', $text);

        foreach ($emails as $key => $email) {
            $text = str_replace($key, $email, $text);
        }
        return $text;
    }

    private function extract_visitor_name($text) {
        $text = $this->normalize_lead_text($text);
        if ($text === '') return '';

        // Remove contact details before searching for a name.
        $safe = preg_replace('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i', ' ', $text);
        $safe = preg_replace('/\+?\d[\d\s\-\(\)]{6,}\d/', ' ', $safe);
        $safe = preg_replace('/\s+/', ' ', trim($safe));

        // Strip greeting words only at the beginning, so "hello it's Harry" becomes "it's Harry".
        $safe_no_greeting = preg_replace('/^\s*(?:hi|hello|hey|salam|assalam|good\s*(?:morning|afternoon|evening))\b[\s,!.:-]*/i', '', $safe);

        $name_piece = '([a-zA-Z][a-zA-Z\'\-]*(?:\s+[a-zA-Z][a-zA-Z\'\-]*){0,3})';
        $stop = '(?=\s*(?:$|[,.;!?]|\band\b|\bbut\b|\bfrom\b|\bin\b|\bat\b|\bfor\b|\bto\b|\bwith\b|\babout\b|\bcan\b|\bcould\b|\bneed\b|\bneeds\b|\bwant\b|\bwants\b|\blooking\b|\bservice\b|\bservices\b|\brepair\b|\binstall\b|\binstallation\b|\bphone\b|\bnumber\b|\bemail\b|\bmail\b))';

        $patterns = [
            '/\b(?:my\s+name\s*(?:is|\'s|=|:)?|name\s*(?:is|=|:)|i\s*(?:am|\'m|m)|i\'m|im|iam|this\s+is|it\s*is|it\'s|its|myself|call\s+me|you\s+can\s+call\s+me)\s+' . $name_piece . $stop . '/i',
            '/\bname\s*[:=]\s*' . $name_piece . $stop . '/i',
            '/^' . $name_piece . '\s+(?:here|speaking)\b/i',
            '/\b' . $name_piece . '\s+(?:here|speaking)\b/i'
        ];

        foreach ([$safe_no_greeting, $safe] as $target) {
            foreach ($patterns as $pattern) {
                if (preg_match($pattern, $target, $m)) {
                    $candidate = $this->clean_name_candidate($m[1]);
                    if ($this->is_likely_person_name($candidate)) return $candidate;
                }
            }
        }

        // Short standalone answers are usually a name after the bot asks for it.
        // Keep this conservative to avoid treating service words as names.
        if (str_word_count($safe) <= 4 && !preg_match('/\b(service|repair|install|quote|price|cost|available|email|phone|number|city|area|location|moving|move|epoxy|drywall|painting|sprinkler|jacuzzi|hot\s*tub)\b/i', $safe)) {
            $candidate = $this->clean_name_candidate($safe);
            if ($this->is_likely_person_name($candidate, $safe)) return $candidate;
        }

        return '';
    }

    private function clean_name_candidate($name) {
        $name = $this->normalize_lead_text($name);
        $name = preg_replace('/\b(?:mr|mrs|ms|miss|dr)\.?\s+/i', '', $name);
        $name = preg_split('/[,.!?;:]|\b(?:and|but|from|in|at|for|to|with|about|because|need|needs|want|wants|looking|service|services|repair|repairs|install|installation|moving|move|quote|estimate|price|cost|phone|number|email|mail|city|area|location|address|please|thanks|thank)\b/i', $name)[0];
        $name = $this->clean_name($name);
        return $name;
    }

    private function is_likely_person_name($candidate, $original = '') {
        $candidate = trim((string)$candidate);
        $candidate_l = strtolower($candidate);
        $original_l = strtolower(trim((string)($original ?: $candidate)));
        if ($candidate === '' || $candidate_l === 'visitor') return false;
        if (preg_match('/^(hi|hello|hey|salam|assalam|good\s*(morning|afternoon|evening))$/i', $original_l)) return false;
        if (preg_match('/^(hi|hello|hey|salam|assalam)\s+(there|dear|sir|madam|bro|friend)?$/i', $original_l)) return false;

        // Reject generic words and service/location phrases. Check the candidate itself,
        // not the whole original sentence, because the original may contain a valid name plus a requirement.
        $reject_patterns = [
            '/\?/',
            '/\d/',
            '/@/',
            '/\b(hi|hello|hey|salam|assalam|i|we|you|your|my|need|want|looking|service|services|repair|install|installation|price|cost|quote|estimate|appointment|schedule|available|help|problem|issue|door|floor|flooring|garage|commercial|epoxy|drywall|painting|moving|move|mover|appliance|sprinkler|hot\s*tub|jacuzzi|tv|mount|los\s+angeles|near\s+me|city|area|location|address|today|tomorrow|email|mail|phone|number)\b/i',
            '/\b(in|at|for|to|from|with|about)\b/i'
        ];
        foreach ($reject_patterns as $pattern) {
            if (preg_match($pattern, $candidate_l)) return false;
        }

        $words = preg_split('/\s+/', $candidate, -1, PREG_SPLIT_NO_EMPTY);
        $count = count($words);
        if ($count < 1 || $count > 4) return false;
        if (strlen($candidate) < 2 || strlen($candidate) > 40) return false;

        foreach ($words as $word) {
            if (strlen($word) < 2) return false;
            if (!preg_match('/^[a-zA-Z][a-zA-Z\-\']*$/', $word)) return false;
        }
        return true;
    }

    private function clean_name($name) {
        $name = $this->normalize_lead_text($name);
        $name = preg_replace('/[^a-zA-Z\s\-\']/', '', $name);
        $name = trim(preg_replace('/\s+/', ' ', $name));
        if ($name === '') return 'Visitor';
        return ucwords(strtolower($name));
    }

    private function extract_phone($text) {
        if (preg_match('/(\+?\d[\d\s\-\(\)]{6,}\d)/', $text, $m)) {
            return trim($m[1]);
        }
        return '';
    }

    private function match_custom_rule($msg, $rules_text) {
        $msg_l = strtolower($msg);
        $lines = preg_split('/\r\n|\r|\n/', (string)$rules_text);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, '=>') === false) continue;
            [$keys, $reply] = array_map('trim', explode('=>', $line, 2));
            if ($reply === '') continue;
            foreach (array_filter(array_map('trim', explode('|', strtolower($keys)))) as $kw) {
                if ($kw !== '' && strpos($msg_l, $kw) !== false) {
                    return $reply;
                }
            }
        }
        return '';
    }

    private function create_lead_from_chat($session, $state, $last_message = '') {
        global $wpdb;
        $s = $this->get_settings();
        $table = $wpdb->prefix . 'mslc_leads';
        $data = [
            'site_id' => $s['site_id'],
            'website_name' => $s['website_name'],
            'category' => $s['category'],
            'visitor_session' => $session,
            'service_type' => sanitize_text_field($state['service_type'] ?? ''),
            'name' => sanitize_text_field($state['name'] ?? ''),
            'phone' => sanitize_text_field($state['phone'] ?? ''),
            'email' => sanitize_email($state['email'] ?? ''),
            'city' => sanitize_text_field($state['city'] ?? ''),
            'message' => sanitize_textarea_field($state['first_message'] ?? $last_message),
            'extra_data' => wp_json_encode(['chat_state' => $state])
        ];
        $inserted = $wpdb->insert($table, $data);
        return $inserted ? $wpdb->insert_id : 0;
    }

    private function fetch_admin_messages($session, $last_id = 0) {
        global $wpdb;
        $session = sanitize_text_field($session);
        $last_id = absint($last_id);

        if ($session === '') return [];

        $table = $wpdb->prefix . 'mslc_chats';
        $exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
        if ($exists !== $table) {
            $this->install_tables();
        }

        // IMPORTANT: Do not filter by site_id here. If admin changes Site ID / Website Name
        // after a lead is created, Telegram can save under the new site_id while the browser
        // still has the old chat session. The session id is unique enough for lookup.
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id, sender, message, created_at FROM $table WHERE visitor_session = %s AND id > %d AND sender = 'admin' ORDER BY id ASC LIMIT 50",
            $session,
            $last_id
        ), ARRAY_A);

        // Safety fallback: if browser has old last_id after reinstall/table reset,
        // return recent admin messages for this session.
        if (empty($rows) && $last_id > 0) {
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT id, sender, message, created_at FROM $table WHERE visitor_session = %s AND sender = 'admin' AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR) ORDER BY id ASC LIMIT 50",
                $session
            ), ARRAY_A);
        }

        return $rows ?: [];
    }

    public function ajax_get_messages() {
        $this->rate_limit('get_messages', 180, 60);
        $session = sanitize_text_field($_POST['session'] ?? '');
        $last_id = absint($_POST['last_id'] ?? 0);
        $this->validate_frontend_request($session);

        if ($session === '' || !$this->validate_frontend_session($session)) {
            wp_send_json_error(['message' => 'Missing or invalid chat session.'], 400);
        }

        wp_send_json_success(['messages' => $this->fetch_admin_messages($session, $last_id)]);
    }

    public function rest_get_messages($request) {
        $session = sanitize_text_field($request->get_param('session') ?? '');
        $last_id = absint($request->get_param('last_id') ?? 0);
        if ($session === '' || !$this->validate_frontend_session($session)) {
            return new WP_REST_Response(['ok' => false, 'message' => 'Missing or invalid chat session.'], 400);
        }
        return new WP_REST_Response(['ok' => true, 'messages' => $this->fetch_admin_messages($session, $last_id)], 200);
    }

    public function rest_debug_session($request) {
        global $wpdb;
        $session = sanitize_text_field($request->get_param('session') ?? '');
        if ($session === '') {
            return new WP_REST_Response(['ok' => false, 'message' => 'Missing session'], 400);
        }
        $table = $wpdb->prefix . 'mslc_chats';
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id, site_id, visitor_session, sender, message, takeover, created_at FROM $table WHERE visitor_session = %s ORDER BY id ASC LIMIT 100",
            $session
        ), ARRAY_A);
        return new WP_REST_Response(['ok' => true, 'session' => $session, 'count' => count($rows ?: []), 'rows' => $rows ?: []], 200);
    }

    private function save_chat($site_id, $session, $sender, $message, $takeover = 0) {
        global $wpdb;
        $inserted = $wpdb->insert($wpdb->prefix . 'mslc_chats', [
            'site_id' => $site_id,
            'visitor_session' => $session,
            'sender' => $sender,
            'message' => $message,
            'takeover' => intval($takeover)
        ]);

        if (!$inserted) {
            error_log('MSLC save_chat failed: ' . $wpdb->last_error);
            return false;
        }

        return $wpdb->insert_id;
    }

    private function telegram_secret($settings = null) {
        $s = $settings ?: $this->get_settings();
        if (empty($s['telegram_bot_token'])) return '';
        return md5('mslc|' . home_url('/') . '|' . trim($s['telegram_bot_token']));
    }

    private function telegram_webhook_url($settings = null) {
        $secret = $this->telegram_secret($settings);
        return rest_url('mslc/v1/telegram/' . $secret);
    }

    public function register_telegram_routes() {
        register_rest_route('mslc/v1', '/telegram/(?P<secret>[a-f0-9]{32})', [
            'methods' => 'POST',
            'callback' => [$this, 'handle_telegram_webhook'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route('mslc/v1', '/messages', [
            'methods' => 'GET',
            'callback' => [$this, 'rest_get_messages'],
            'permission_callback' => function () { return current_user_can('manage_options'); }
        ]);


        register_rest_route('mslc/v1', '/debug-session', [
            'methods' => 'GET',
            'callback' => [$this, 'rest_debug_session'],
            'permission_callback' => function () { return current_user_can('manage_options'); }
        ]);
    }

    public function admin_set_telegram_webhook() {
        if (!current_user_can('manage_options')) wp_die('Not allowed.');
        check_admin_referer('mslc_set_telegram_webhook');

        $s = $this->get_settings();
        if (empty($s['telegram_bot_token'])) {
            wp_safe_redirect(admin_url('admin.php?page=mslc-settings&mslc_webhook=missing_token'));
            exit;
        }

        $url = $this->telegram_webhook_url($s);
        $api = 'https://api.telegram.org/bot' . trim($s['telegram_bot_token']) . '/setWebhook';
        $response = wp_remote_post($api, [
            'timeout' => 20,
            'body' => [
                'url' => $url,
                'drop_pending_updates' => 'false'
            ]
        ]);

        $ok = false;
        if (!is_wp_error($response)) {
            $body = json_decode(wp_remote_retrieve_body($response), true);
            $ok = !empty($body['ok']);
        }

        wp_safe_redirect(admin_url('admin.php?page=mslc-settings&mslc_webhook=' . ($ok ? 'success' : 'failed')));
        exit;
    }

    private function session_meta_key($session) {
        return 'mslc_session_meta_' . md5(sanitize_text_field($session));
    }

    private function get_session_meta($session) {
        $key = $this->session_meta_key($session);
        $meta = get_transient($key);
        if (!is_array($meta)) $meta = [];
        return $meta;
    }

    private function set_session_meta($session, $meta, $ttl = null) {
        if (!is_array($meta)) $meta = [];
        set_transient($this->session_meta_key($session), $meta, $ttl ?: 12 * HOUR_IN_SECONDS);
        return $meta;
    }

    private function mark_session_taken($session) {
        $session = sanitize_text_field((string)$session);
        if (!$this->validate_frontend_session($session)) return false;
        set_transient('mslc_session_taken_' . md5($session), 1, 12 * HOUR_IN_SECONDS);
        $taken = get_option('mslc_taken_sessions', []);
        if (!is_array($taken)) $taken = [];
        $taken[$session] = time();
        foreach ($taken as $k => $t) {
            if (time() - intval($t) > 12 * HOUR_IN_SECONDS) unset($taken[$k]);
        }
        update_option('mslc_taken_sessions', $taken, false);
        return true;
    }

    private function is_session_taken($session) {
        $session = sanitize_text_field((string)$session);
        if (!$this->validate_frontend_session($session)) return false;
        if (get_transient('mslc_session_taken_' . md5($session))) return true;
        $taken = get_option('mslc_taken_sessions', []);
        if (is_array($taken) && !empty($taken[$session]) && time() - intval($taken[$session]) <= 12 * HOUR_IN_SECONDS) return true;
        return false;
    }

    private function ensure_session_meta($session) {
        $meta = $this->get_session_meta($session);
        if (empty($meta['visitor_label'])) {
            $n = intval(get_option('mslc_visitor_counter', 0)) + 1;
            update_option('mslc_visitor_counter', $n, false);
            $meta['visitor_number'] = $n;
            $meta['visitor_label'] = 'Visitor ' . $n;
        }
        if (empty($meta['display_name'])) {
            $meta['display_name'] = $meta['visitor_name'] ?? $meta['visitor_label'];
        }
        if (empty($meta['lines'])) $meta['lines'] = [];
        return $this->set_session_meta($session, $meta);
    }

    private function update_session_visitor_name($session, $name) {
        $name = trim((string)$name);
        if ($name === '' || strtolower($name) === 'visitor') return $this->ensure_session_meta($session);
        $meta = $this->ensure_session_meta($session);
        $meta['visitor_name'] = sanitize_text_field($name);
        $meta['display_name'] = sanitize_text_field($name);
        $saved = $this->set_session_meta($session, $meta);
        $this->maybe_rename_telegram_topic($session);
        return $saved;
    }

    private function session_display_name($session) {
        $meta = $this->ensure_session_meta($session);
        return !empty($meta['display_name']) ? $meta['display_name'] : ($meta['visitor_label'] ?? 'Visitor');
    }

    private function session_header_lines($session) {
        $meta = $this->ensure_session_meta($session);
        $visitor_label = !empty($meta['visitor_label']) ? $meta['visitor_label'] : 'Visitor';
        $visitor_name = !empty($meta['visitor_name']) ? $meta['visitor_name'] : '';
        $lines = [];
        $lines[] = 'Visitor: ' . $visitor_label;
        if ($visitor_name !== '') {
            $lines[] = 'Name: ' . $visitor_name;
        } else {
            $lines[] = 'Name: Not collected yet';
        }
        return $lines;
    }

    private function takeover_context_text($session, $s = null) {
        $settings = $s ?: $this->get_settings();
        $meta = $this->ensure_session_meta($session);
        $visitor_label = !empty($meta['visitor_label']) ? $meta['visitor_label'] : 'Visitor';
        $visitor_name = !empty($meta['visitor_name']) ? $meta['visitor_name'] : 'Not collected yet';
        $website = !empty($settings['website_name']) ? $settings['website_name'] : get_bloginfo('name');

        $lines = [];
        $lines[] = '🟢 Active takeover';
        $lines[] = 'Website: ' . $website;
        $lines[] = 'Visitor: ' . $visitor_label;
        $lines[] = 'Name: ' . $visitor_name;
        $lines[] = '';
        $lines[] = 'Your next messages will be sent to this visitor.';
        return implode("\n", array_map('wp_strip_all_tags', $lines));
    }

    private function takeover_context_short_label($session) {
        $meta = $this->ensure_session_meta($session);
        $visitor_label = !empty($meta['visitor_label']) ? $meta['visitor_label'] : 'Visitor';
        $visitor_name = !empty($meta['visitor_name']) ? $meta['visitor_name'] : '';
        return $visitor_name !== '' ? ($visitor_name . ' (' . $visitor_label . ')') : $visitor_label;
    }

    private function takeover_context_key($chat_id, $thread_id, $from_id, $site_id) {
        return md5((string)$chat_id . '|' . (string)$thread_id . '|' . (string)$from_id . '|' . (string)$site_id);
    }

    private function topic_map_key($chat_id, $thread_id, $site_id) {
        return md5((string)$chat_id . '|' . (string)$thread_id . '|' . (string)$site_id);
    }

    private function save_topic_session_map($chat_id, $thread_id, $session, $s) {
        if ($chat_id === '' || $thread_id === '' || $session === '') return false;
        $map = get_option('mslc_topic_session_map', []);
        if (!is_array($map)) $map = [];
        $map[$this->topic_map_key($chat_id, $thread_id, $s['site_id'])] = [
            'session' => sanitize_text_field($session),
            'chat_id' => (string)$chat_id,
            'thread_id' => (string)$thread_id,
            'site_id' => sanitize_text_field($s['site_id']),
            'time' => time()
        ];
        foreach ($map as $k => $v) {
            if (empty($v['time']) || time() - intval($v['time']) > 7 * DAY_IN_SECONDS) unset($map[$k]);
        }
        update_option('mslc_topic_session_map', $map, false);
        return true;
    }

    private function get_session_by_topic($chat_id, $thread_id, $s) {
        if ($chat_id === '' || $thread_id === '') return '';
        $map = get_option('mslc_topic_session_map', []);
        $key = $this->topic_map_key($chat_id, $thread_id, $s['site_id']);
        if (is_array($map) && !empty($map[$key]['session'])) return sanitize_text_field($map[$key]['session']);
        return '';
    }

    private function telegram_topic_title($session, $s) {
        $meta = $this->ensure_session_meta($session);
        $visitor = !empty($meta['visitor_name']) ? $meta['visitor_name'] : ($meta['visitor_label'] ?? 'Visitor');
        $website = !empty($s['website_name']) ? $s['website_name'] : get_bloginfo('name');
        $title = sanitize_text_field($visitor . ' - ' . $website);
        if (function_exists('mb_substr')) return mb_substr($title, 0, 120);
        return substr($title, 0, 120);
    }

    private function ensure_telegram_topic_for_session($session, $s = null) {
        $s = $s ?: $this->get_settings();
        if ($s['telegram_enabled'] !== '1') return '';
        if (empty($s['telegram_bot_token']) || empty($s['telegram_group_id'])) return '';
        $session = sanitize_text_field($session);
        if (!$this->validate_frontend_session($session)) return '';

        $meta = $this->ensure_session_meta($session);
        $token = trim((string)$s['telegram_bot_token']);
        $chat_id = trim((string)$s['telegram_group_id']);
        if (!empty($meta['telegram_thread_id'])) {
            $this->save_topic_session_map($chat_id, (string)$meta['telegram_thread_id'], $session, $s);
            return (string)$meta['telegram_thread_id'];
        }
        $payload = [
            'chat_id' => $chat_id,
            'name' => $this->telegram_topic_title($session, $s)
        ];
        $response = wp_remote_post('https://api.telegram.org/bot' . $token . '/createForumTopic', [
            'timeout' => 20,
            'body' => $payload
        ]);
        if (is_wp_error($response)) {
            error_log('MSLC Telegram createForumTopic failed: ' . $response->get_error_message());
            return '';
        }
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (empty($body['ok']) || empty($body['result']['message_thread_id'])) {
            error_log('MSLC Telegram createForumTopic API failed: ' . wp_remote_retrieve_body($response));
            return '';
        }
        $thread_id = (string)intval($body['result']['message_thread_id']);
        $meta['telegram_thread_id'] = $thread_id;
        $this->set_session_meta($session, $meta, 7 * DAY_IN_SECONDS);
        $this->save_topic_session_map($chat_id, $thread_id, $session, $s);
        return $thread_id;
    }

    private function maybe_rename_telegram_topic($session, $s = null) {
        $s = $s ?: $this->get_settings();
        $meta = $this->get_session_meta($session);
        if (empty($meta['telegram_thread_id']) || empty($s['telegram_bot_token']) || empty($s['telegram_group_id'])) return false;
        $response = wp_remote_post('https://api.telegram.org/bot' . trim($s['telegram_bot_token']) . '/editForumTopic', [
            'timeout' => 10,
            'body' => [
                'chat_id' => trim($s['telegram_group_id']),
                'message_thread_id' => intval($meta['telegram_thread_id']),
                'name' => $this->telegram_topic_title($session, $s)
            ]
        ]);
        return !is_wp_error($response);
    }

    private function send_or_update_takeover_context($chat_id, $thread_id, $from_id, $session, $s) {
        if (empty($s['telegram_bot_token']) || empty($chat_id)) return false;
        $token = trim((string)$s['telegram_bot_token']);
        $text = $this->takeover_context_text($session, $s);
        $key = $this->takeover_context_key($chat_id, $thread_id, $from_id, $s['site_id']);
        $contexts = get_option('mslc_takeover_context_messages', []);
        if (!is_array($contexts)) $contexts = [];

        $base_payload = [
            'chat_id' => (string)$chat_id,
            'text' => $text,
            'disable_web_page_preview' => 'true'
        ];
        if ($thread_id !== '') {
            $base_payload['message_thread_id'] = intval($thread_id);
        }

        if (!empty($contexts[$key]['message_id'])) {
            $edit_payload = $base_payload;
            unset($edit_payload['message_thread_id']);
            $edit_payload['message_id'] = intval($contexts[$key]['message_id']);
            $edit = wp_remote_post('https://api.telegram.org/bot' . $token . '/editMessageText', [
                'timeout' => 10,
                'body' => $edit_payload
            ]);
            if (!is_wp_error($edit)) {
                $body = json_decode(wp_remote_retrieve_body($edit), true);
                if (!empty($body['ok'])) {
                    $contexts[$key]['session'] = sanitize_text_field($session);
                    $contexts[$key]['time'] = time();
                    update_option('mslc_takeover_context_messages', $contexts, false);
                    return true;
                }
            }
        }

        $send = wp_remote_post('https://api.telegram.org/bot' . $token . '/sendMessage', [
            'timeout' => 10,
            'body' => $base_payload
        ]);
        if (is_wp_error($send)) return false;
        $body = json_decode(wp_remote_retrieve_body($send), true);
        if (!empty($body['ok']) && !empty($body['result']['message_id'])) {
            $contexts[$key] = [
                'message_id' => intval($body['result']['message_id']),
                'session' => sanitize_text_field($session),
                'time' => time()
            ];
            foreach ($contexts as $k => $v) {
                if (empty($v['time']) || time() - intval($v['time']) > 12 * HOUR_IN_SECONDS) unset($contexts[$k]);
            }
            update_option('mslc_takeover_context_messages', $contexts, false);
            return true;
        }
        return false;
    }

    private function set_latest_takeover_session($chat_id, $thread_id, $from_id, $session, $s) {
        $session = sanitize_text_field($session);
        $chat_id = (string)$chat_id;
        $thread_id = (string)$thread_id;
        $from_id = (string)$from_id;
        $site_id = $s['site_id'];

        // Mobile Telegram sometimes sends the next admin message from General or without a stable topic id.
        // Save takeover state in several scopes so the selected visitor remains active on desktop and mobile.
        $state = ['session' => $session, 'site_id' => $site_id, 'thread_id' => $thread_id, 'admin_id' => $from_id, 'time' => time()];
        $ttl = 7 * DAY_IN_SECONDS;

        set_transient('mslc_takeover_' . md5($chat_id . '|' . $from_id . '|' . $site_id), $state, $ttl);
        set_transient('mslc_takeover_chat_' . md5($chat_id . '|' . $site_id), $state, $ttl);
        set_transient('mslc_takeover_mobile_' . md5($chat_id . '|' . $from_id . '|' . $site_id), $state, $ttl);
        if ($thread_id !== '') {
            set_transient('mslc_takeover_thread_' . md5($chat_id . '|' . $thread_id . '|' . $site_id), $state, $ttl);
        }

        $persist = get_option('mslc_takeover_persist', []);
        if (!is_array($persist)) $persist = [];
        $persist[md5($chat_id . '|' . $from_id . '|' . $site_id)] = $state;
        $persist[md5($chat_id . '|' . $site_id)] = $state;
        $persist['mobile_' . md5($chat_id . '|' . $from_id . '|' . $site_id)] = $state;
        if ($thread_id !== '') $persist[md5($chat_id . '|' . $thread_id . '|' . $site_id)] = $state;
        foreach ($persist as $k => $v) {
            if (empty($v['time']) || time() - intval($v['time']) > $ttl) unset($persist[$k]);
        }
        update_option('mslc_takeover_persist', $persist, false);
        update_option('mslc_last_takeover_selected', $state + ['chat_id' => $chat_id], false);
        $this->mark_session_taken($session);
    }

    private function get_active_takeover_session($chat_id, $thread_id, $from_id, $s) {
        $site_id = $s['site_id'];
        $chat_id = (string)$chat_id;
        $thread_id = (string)$thread_id;
        $from_id = (string)$from_id;
        $ttl = 7 * DAY_IN_SECONDS;
        $keys = [
            'mslc_takeover_' . md5($chat_id . '|' . $from_id . '|' . $site_id),
            'mslc_takeover_mobile_' . md5($chat_id . '|' . $from_id . '|' . $site_id)
        ];
        if ($thread_id !== '') {
            $keys[] = 'mslc_takeover_thread_' . md5($chat_id . '|' . $thread_id . '|' . $site_id);
        }
        // Last fallback: chat-wide active visitor. This fixes Telegram mobile when the app posts from General.
        $keys[] = 'mslc_takeover_chat_' . md5($chat_id . '|' . $site_id);
        foreach ($keys as $key) {
            $state = get_transient($key);
            if (!empty($state['session'])) return $state;
        }
        $persist = get_option('mslc_takeover_persist', []);
        if (is_array($persist)) {
            $persist_keys = [
                md5($chat_id . '|' . $from_id . '|' . $site_id),
                'mobile_' . md5($chat_id . '|' . $from_id . '|' . $site_id)
            ];
            if ($thread_id !== '') $persist_keys[] = md5($chat_id . '|' . $thread_id . '|' . $site_id);
            $persist_keys[] = md5($chat_id . '|' . $site_id);
            foreach ($persist_keys as $pkey) {
                if (!empty($persist[$pkey]['session']) && time() - intval($persist[$pkey]['time'] ?? 0) <= $ttl) return $persist[$pkey];
            }
        }
        $last = get_option('mslc_last_takeover_selected', []);
        if (is_array($last) && !empty($last['session']) && (string)($last['chat_id'] ?? '') === $chat_id && (string)($last['site_id'] ?? '') === (string)$site_id && time() - intval($last['time'] ?? 0) <= $ttl) {
            return $last;
        }
        return [];
    }

    private function append_session_transcript($session, $sender, $message) {
        $meta = $this->ensure_session_meta($session);
        $lines = $meta['lines'] ?? [];
        $label = sanitize_text_field($sender);
        if (strtolower($label) === 'visitor' && !empty($meta['visitor_name'])) {
            $label = sanitize_text_field($meta['visitor_name']);
        }
        $clean = trim(wp_strip_all_tags((string)$message));
        if ($clean !== '') $lines[] = $label . ': ' . $clean;
        if (count($lines) > 18) $lines = array_slice($lines, -18);
        $meta['lines'] = $lines;
        return $this->set_session_meta($session, $meta);
    }

    private function mark_telegram_message_sent($chat_id, $message_id) {
        $s = $this->get_settings();
        if (empty($s['telegram_bot_token']) || empty($chat_id) || empty($message_id)) return false;
        $payload = [
            'chat_id' => $chat_id,
            'message_id' => intval($message_id),
            'reaction' => wp_json_encode([['type' => 'emoji', 'emoji' => '✅']])
        ];
        $response = wp_remote_post('https://api.telegram.org/bot' . trim($s['telegram_bot_token']) . '/setMessageReaction', [
            'timeout' => 10,
            'body' => $payload
        ]);
        return !is_wp_error($response);
    }

    private function delete_telegram_message($chat_id, $message_id) {
        $s = $this->get_settings();
        if (empty($s['telegram_bot_token']) || empty($chat_id) || empty($message_id)) return false;
        $response = wp_remote_post('https://api.telegram.org/bot' . trim($s['telegram_bot_token']) . '/deleteMessage', [
            'timeout' => 10,
            'body' => [
                'chat_id' => $chat_id,
                'message_id' => intval($message_id)
            ]
        ]);
        return !is_wp_error($response);
    }

    private function mirror_mobile_admin_message_to_topic($chat_id, $incoming_thread_id, $message_id, $state, $text) {
        $s = $this->get_settings();
        $target_thread_id = (string)($state['thread_id'] ?? '');
        $incoming_thread_id = (string)$incoming_thread_id;
        if (empty($s['telegram_bot_token']) || $target_thread_id === '' || $target_thread_id === $incoming_thread_id || trim((string)$text) === '') {
            return false;
        }

        // Telegram mobile can submit the admin reply from General while the active takeover
        // visitor is saved against a topic. Copy the admin text back into the visitor topic
        // so the Telegram-side conversation remains in the correct thread.
        $sent = $this->send_telegram_text('Admin: ' . trim((string)$text), $chat_id, $target_thread_id, null);

        // If the message was sent from General/wrong thread, remove the misplaced copy when
        // the bot has permission. If deletion is not allowed, delivery still works.
        if ($sent && !empty($message_id)) {
            $this->delete_telegram_message($chat_id, $message_id);
        }
        return $sent;
    }

    private function handle_telegram_callback($callback, $s) {
        $data = sanitize_text_field($callback['data'] ?? '');
        $callback_id = sanitize_text_field($callback['id'] ?? '');
        $message = $callback['message'] ?? [];
        $chat_id = (string)($message['chat']['id'] ?? '');
        $from_id = (string)($callback['from']['id'] ?? 'unknown');

        if ($chat_id !== trim((string)$s['telegram_group_id'])) {
            $this->answer_telegram_callback($callback_id, 'This bot is connected to another Telegram group.');
            return new WP_REST_Response(['ok' => true, 'ignored' => 'different chat'], 200);
        }

        if (strpos($data, 'takeover:') !== 0) {
            $this->answer_telegram_callback($callback_id, 'Unknown action.');
            return new WP_REST_Response(['ok' => true, 'ignored' => 'unknown callback'], 200);
        }

        $session = sanitize_text_field(substr($data, strlen('takeover:')));
        if ($session === '') {
            $this->answer_telegram_callback($callback_id, 'Missing session.');
            return new WP_REST_Response(['ok' => false, 'error' => 'missing session'], 400);
        }

        $thread_id = (string)($message['message_thread_id'] ?? '');
        if ($thread_id === '') {
            $meta = $this->get_session_meta($session);
            if (!empty($meta['telegram_thread_id'])) {
                $thread_id = (string)$meta['telegram_thread_id'];
            }
        }
        if ($thread_id !== '') {
            $this->save_topic_session_map($chat_id, $thread_id, $session, $s);
        }
        $this->set_latest_takeover_session($chat_id, $thread_id, $from_id, $session, $s);

        $this->answer_telegram_callback($callback_id, 'Takeover active: ' . $this->takeover_context_short_label($session));
        // A single context label is shown in Telegram so the admin knows which visitor is active.
        return new WP_REST_Response(['ok' => true, 'takeover' => $session], 200);
    }

    private function answer_telegram_callback($callback_id, $text) {
        $s = $this->get_settings();
        if (empty($callback_id) || empty($s['telegram_bot_token'])) return false;
        wp_remote_post('https://api.telegram.org/bot' . trim($s['telegram_bot_token']) . '/answerCallbackQuery', [
            'timeout' => 10,
            'body' => [
                'callback_query_id' => $callback_id,
                'text' => $text,
                'show_alert' => 'false'
            ]
        ]);
        return true;
    }


    private function maybe_auto_save_group_chat_id($chat_id, $message, $s) {
        $chat_type = (string)($message['chat']['type'] ?? '');
        if (!in_array($chat_type, ['group', 'supergroup'], true)) return $s;
        $configured = trim((string)($s['telegram_group_id'] ?? ''));
        if ($configured !== '' || $chat_id === '') return $s;

        $settings = get_option($this->option, []);
        if (!is_array($settings)) $settings = [];
        $settings['telegram_group_id'] = sanitize_text_field($chat_id);
        $settings['telegram_thread_id'] = '';
        update_option($this->option, wp_parse_args($settings, $this->defaults()));
        $s = $this->get_settings();

        $this->send_telegram_text("✅ Telegram group connected.

Group ID: " . $chat_id . "

Now every new website visitor will get a separate topic automatically. Reply inside that visitor topic to answer them on the website chat.", $chat_id, $message['message_thread_id'] ?? null, $message['message_id'] ?? null);
        return $s;
    }
    public function handle_telegram_webhook($request) {
        $s = $this->get_settings();
        $secret = sanitize_text_field($request['secret'] ?? '');
        if ($secret === '' || !hash_equals($this->telegram_secret($s), $secret)) {
            return new WP_REST_Response(['ok' => false, 'error' => 'Invalid secret'], 403);
        }

        $update = $request->get_json_params();

        if (!empty($update['callback_query'])) {
            return $this->handle_telegram_callback($update['callback_query'], $s);
        }

        $message = $update['message'] ?? null;
        if (!$message || empty($message['text'])) {
            return new WP_REST_Response(['ok' => true, 'ignored' => 'no text message'], 200);
        }

        $chat_id = (string)($message['chat']['id'] ?? '');
        $s = $this->maybe_auto_save_group_chat_id($chat_id, $message, $s);
        $configured_chat_id = trim((string)($s['telegram_group_id'] ?? ''));
        if ($configured_chat_id !== '' && $chat_id !== $configured_chat_id) {
            return new WP_REST_Response(['ok' => true, 'ignored' => 'different chat'], 200);
        }
        if ($configured_chat_id === '') {
            return new WP_REST_Response(['ok' => true, 'ignored' => 'telegram group not connected yet'], 200);
        }

        if (!empty($message['from']['is_bot'])) {
            return new WP_REST_Response(['ok' => true, 'ignored' => 'bot message'], 200);
        }

        $text = trim((string)$message['text']);
        $from_id = (string)($message['from']['id'] ?? ($message['sender_chat']['id'] ?? 'unknown'));
        $incoming_thread_id_for_state = (string)($message['message_thread_id'] ?? '');
        $state_key = 'mslc_takeover_' . md5($chat_id . '|' . $from_id . '|' . $s['site_id']);

        if (preg_match('/^\/(start|id)(?:@\w+)?/i', $text)) {
            $this->send_telegram_text("✅ This Telegram group is connected.
Group ID: " . $chat_id . "

When a website visitor sends the first message, a separate topic will be created here automatically.", $chat_id, null, $message['message_id'] ?? null);
            return new WP_REST_Response(['ok' => true, 'connected_chat_id' => $chat_id], 200);
        }

        if (preg_match('/^\/online(?:@\w+)?/i', $text)) {
            $this->set_admin_live_mode(true);
            $this->send_telegram_text('✅ Admin is ONLINE. AI lead questions are off. New visitor messages will go to Telegram topics, and the website bot will stay silent until admin replies.', $chat_id, $message['message_thread_id'] ?? null, $message['message_id'] ?? null);
            return new WP_REST_Response(['ok' => true, 'admin_live_mode' => 'on'], 200);
        }

        if (preg_match('/^\/offline(?:@\w+)?/i', $text)) {
            $this->set_admin_live_mode(false);
            $this->send_telegram_text('✅ Admin is OFFLINE. AI lead collection is on again.', $chat_id, $message['message_thread_id'] ?? null, $message['message_id'] ?? null);
            return new WP_REST_Response(['ok' => true, 'admin_live_mode' => 'off'], 200);
        }

        if (preg_match('/^\/status(?:@\w+)?/i', $text)) {
            $this->send_telegram_text($this->is_admin_live_mode($s) ? '🟢 Admin is ONLINE. AI is silent.' : '⚪ Admin is OFFLINE. AI lead collection is active.', $chat_id, $message['message_thread_id'] ?? null, $message['message_id'] ?? null);
            return new WP_REST_Response(['ok' => true, 'admin_live_mode' => $this->is_admin_live_mode($s) ? 'on' : 'off'], 200);
        }

        if (preg_match('/^\/takeover(?:@\w+)?\s+([^\s]+)/i', $text, $m)) {
            $session = sanitize_text_field($m[1]);
            $this->set_latest_takeover_session($chat_id, $incoming_thread_id_for_state, $from_id, $session, $s);

            return new WP_REST_Response(['ok' => true, 'takeover' => $session, 'visitor' => $this->takeover_context_short_label($session)], 200);
        }

        if (preg_match('/^\/stop(?:@\w+)?/i', $text)) {
            $old_state = $this->get_active_takeover_session($chat_id, $incoming_thread_id_for_state, $from_id, $s);
            if (!empty($old_state['session'])) {
                delete_transient('mslc_session_taken_' . md5($old_state['session']));
                $taken = get_option('mslc_taken_sessions', []);
                if (is_array($taken)) { unset($taken[$old_state['session']]); update_option('mslc_taken_sessions', $taken, false); }
            }
            delete_transient($state_key);
            delete_transient('mslc_takeover_chat_' . md5($chat_id . '|' . $s['site_id']));
            if ($incoming_thread_id_for_state !== '') delete_transient('mslc_takeover_thread_' . md5($chat_id . '|' . $incoming_thread_id_for_state . '|' . $s['site_id']));
            $this->send_telegram_text('✅ Takeover stopped for you.', $chat_id, $message['message_thread_id'] ?? null, $message['message_id'] ?? null);
            return new WP_REST_Response(['ok' => true, 'stopped' => true], 200);
        }

        if (strpos($text, '/') === 0) {
            return new WP_REST_Response(['ok' => true, 'ignored' => 'unknown command'], 200);
        }

        $topic_session = $this->get_session_by_topic($chat_id, $incoming_thread_id_for_state, $s);
        if ($topic_session !== '') {
            $state = ['session' => $topic_session, 'site_id' => $s['site_id']];
            $this->mark_session_taken($topic_session);
            $this->set_latest_takeover_session($chat_id, $incoming_thread_id_for_state, $from_id, $topic_session, $s);
        } else {
            $state = $this->get_active_takeover_session($chat_id, $incoming_thread_id_for_state, $from_id, $s);
        }

        if (empty($state['session'])) {
            $this->send_telegram_text('ℹ️ No visitor is linked to this topic yet. Reply inside a visitor topic, or use the Takeover button from a visitor chat.', $chat_id, $message['message_thread_id'] ?? null, $message['message_id'] ?? null);
            return new WP_REST_Response(['ok' => true, 'ignored' => 'no active takeover'], 200);
        }

        $saved = $this->save_chat($s['site_id'], sanitize_text_field($state['session']), 'admin', sanitize_textarea_field($text), 1);
        if (!$saved) {
            $this->install_tables();
            $saved = $this->save_chat($s['site_id'], sanitize_text_field($state['session']), 'admin', sanitize_textarea_field($text), 1);
        }
        if (!$saved) {
            $this->send_telegram_text('❌ Message received, but WordPress could not save it to the chat database. Deactivate/reactivate the plugin and try again.', $chat_id, $message['message_thread_id'] ?? null, $message['message_id'] ?? null);
            return new WP_REST_Response(['ok' => false, 'error' => 'chat database insert failed'], 500);
        }
        update_option('mslc_last_takeover_debug', ['session' => sanitize_text_field($state['session']), 'message' => sanitize_textarea_field($text), 'chat_id' => $chat_id, 'thread_id' => $incoming_thread_id_for_state, 'target_thread_id' => (string)($state['thread_id'] ?? ''), 'from_id' => $from_id, 'time' => current_time('mysql')], false);
        $mirrored = $this->mirror_mobile_admin_message_to_topic($chat_id, $incoming_thread_id_for_state, $message['message_id'] ?? 0, $state, $text);
        // Mark the admin's own Telegram message with a check reaction when it is already in the correct topic.
        if (!$mirrored) {
            $this->mark_telegram_message_sent($chat_id, $message['message_id'] ?? 0);
        }
        return new WP_REST_Response(['ok' => true, 'sent_to_session' => $state['session'], 'mirrored_to_topic' => $mirrored], 200);
    }

    private function takeover_keyboard($session) {
        $session = sanitize_text_field($session);
        return wp_json_encode([
            'inline_keyboard' => [[
                ['text' => 'Takeover this chat', 'callback_data' => 'takeover:' . $session]
            ]]
        ]);
    }

    private function send_telegram_takeover_visitor_message($session, $message) {
        $s = $this->get_settings();
        if ($s['telegram_enabled'] !== '1') return true;
        if (empty($s['telegram_bot_token']) || empty($s['telegram_group_id'])) return false;

        $session = sanitize_text_field($session);
        $clean = trim(sanitize_textarea_field($message));
        if ($clean === '') return true;

        // After takeover, keep Telegram like a normal chat: no repeated website/visitor header cards.
        $thread_id = $this->ensure_telegram_topic_for_session($session, $s);
        $payload = [
            'chat_id' => trim($s['telegram_group_id']),
            'text' => $clean,
            'disable_web_page_preview' => 'true'
        ];
        if ($thread_id !== '') {
            $payload['message_thread_id'] = intval($thread_id);
        }
        $response = wp_remote_post('https://api.telegram.org/bot' . trim($s['telegram_bot_token']) . '/sendMessage', [
            'timeout' => 20,
            'body' => $payload
        ]);
        if (preg_match('/Attachment:\s*(https?:\/\/\S+)/i', $clean, $m)) {
            $this->send_telegram_attachment_url($m[1], 'Visitor attachment', trim($s['telegram_group_id']), $thread_id);
        }
        return !is_wp_error($response);
    }

    private function send_telegram_chat_update($session, $sender, $message, $title = 'Chat update') {
        $s = $this->get_settings();
        if ($s['telegram_enabled'] !== '1') return true;
        if (empty($s['telegram_bot_token']) || empty($s['telegram_group_id'])) return false;

        $session = sanitize_text_field($session);
        $sender = sanitize_text_field($sender);
        $message = sanitize_textarea_field($message);
        $thread_id = $this->ensure_telegram_topic_for_session($session, $s);
        $meta = $this->append_session_transcript($session, $sender, $message);
        if ($thread_id !== '') {
            $meta['telegram_thread_id'] = $thread_id;
        }

        $lines = $meta['lines'] ?? [];
        $header = $this->session_header_lines($session);
        $text = "💬 Website Chat\n\n";
        $text .= "Website: " . $s['website_name'] . "\n";
        $text .= implode("\n", $header) . "\n\n";
        $text .= "Conversation:\n" . implode("\n", $lines);

        if (strlen($text) > 3900) {
            $text = substr($text, 0, 3900) . "\n...";
        }

        $token = trim($s['telegram_bot_token']);
        $chat_id = trim($s['telegram_group_id']);
        $payload = [
            'chat_id' => $chat_id,
            'text' => $text,
            'reply_markup' => $this->takeover_keyboard($session)
        ];
        if ($thread_id !== '') {
            $payload['message_thread_id'] = intval($thread_id);
        }
        if (!empty($meta['telegram_message_id'])) {
            $edit_payload = [
                'chat_id' => $chat_id,
                'message_id' => intval($meta['telegram_message_id']),
                'text' => $text,
                'reply_markup' => $this->takeover_keyboard($session)
            ];
            $response = wp_remote_post('https://api.telegram.org/bot' . $token . '/editMessageText', [
                'timeout' => 20,
                'body' => $edit_payload
            ]);
            if (!is_wp_error($response)) {
                $body = json_decode(wp_remote_retrieve_body($response), true);
                if (!empty($body['ok'])) { if (preg_match('/Attachment:\s*(https?:\/\/\S+)/i', $message, $m)) { $this->send_telegram_attachment_url($m[1], 'Visitor attachment', $chat_id, $thread_id); } return true; }
            }
        }

        $response = wp_remote_post('https://api.telegram.org/bot' . $token . '/sendMessage', [
            'timeout' => 20,
            'body' => $payload
        ]);
        if (is_wp_error($response)) return false;
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (!empty($body['ok']) && !empty($body['result']['message_id'])) {
            $meta['telegram_message_id'] = intval($body['result']['message_id']);
            set_transient($this->session_meta_key($session), $meta, 12 * HOUR_IN_SECONDS);
        }
        if (!empty($body['ok']) && preg_match('/Attachment:\s*(https?:\/\/\S+)/i', $message, $m)) {
            $this->send_telegram_attachment_url($m[1], 'Visitor attachment', $chat_id, $thread_id);
        }
        return !empty($body['ok']);
    }

    private function send_telegram_text($text, $chat_id = null, $thread_id = null, $reply_to_message_id = null) {
        $s = $this->get_settings();
        if ($s['telegram_enabled'] !== '1' || empty($s['telegram_bot_token'])) return false;

        $payload = [
            'chat_id' => $chat_id ?: trim($s['telegram_group_id']),
            'text' => $text
        ];

        if (!empty($thread_id)) {
            $payload['message_thread_id'] = intval($thread_id);
        }

        if (!empty($reply_to_message_id)) {
            $payload['reply_to_message_id'] = intval($reply_to_message_id);
            $payload['allow_sending_without_reply'] = true;
        }

        $response = wp_remote_post('https://api.telegram.org/bot' . trim($s['telegram_bot_token']) . '/sendMessage', [
            'timeout' => 20,
            'body' => $payload
        ]);

        return !is_wp_error($response);
    }

    private function send_telegram_attachment_url($url, $caption = '', $chat_id = null, $thread_id = null) {
        $s = $this->get_settings();
        if ($s['telegram_enabled'] !== '1' || empty($s['telegram_bot_token']) || empty($url)) return false;
        $token = trim($s['telegram_bot_token']);
        $chat_id = $chat_id ?: trim($s['telegram_group_id']);
        $url = esc_url_raw($url);
        $caption = trim(sanitize_text_field($caption));
        if (strlen($caption) > 900) $caption = substr($caption, 0, 900) . '...';
        $is_image = preg_match('/\.(png|jpe?g|gif|webp)(\?.*)?$/i', $url);
        $method = $is_image ? 'sendPhoto' : 'sendDocument';
        $payload = [
            'chat_id' => $chat_id,
            $is_image ? 'photo' : 'document' => $url
        ];
        if ($caption !== '') $payload['caption'] = $caption;
        if (!empty($thread_id)) $payload['message_thread_id'] = intval($thread_id);
        $response = wp_remote_post('https://api.telegram.org/bot' . $token . '/' . $method, [
            'timeout' => 30,
            'body' => $payload
        ]);
        return !is_wp_error($response);
    }

    private function send_telegram_lead($lead_id, $lead) {
        $s = $this->get_settings();
        if ($s['telegram_enabled'] !== '1') return true;
        if (empty($s['telegram_bot_token']) || empty($s['telegram_group_id'])) {
            return new WP_Error('mslc_telegram_missing', 'Telegram bot token or group ID is missing.');
        }

        $visitor_session = sanitize_text_field($lead['visitor_session'] ?? '');
        $thread_id = $this->ensure_telegram_topic_for_session($visitor_session, $s);
        $header = $this->session_header_lines($visitor_session);
        $text = "🚨 NEW LEAD\n\n";
        $text .= "Website: " . $lead['website_name'] . "\n";
        $text .= "Lead ID: " . $lead_id . "\n";
        $text .= implode("\n", $header) . "\n";
        $text .= "Service: " . $lead['service_type'] . "\n\n";
        $text .= "Name: " . $lead['name'] . "\n";
        $text .= "Phone: " . $lead['phone'] . "\n";
        $text .= "Email: " . $lead['email'] . "\n";
        $text .= "City: " . $lead['city'] . "\n\n";
        $text .= "Message:\n" . $lead['message'] . "\n\n";
        $text .= "Tap the button below to takeover without copying.";

        $payload = [
            'chat_id' => trim($s['telegram_group_id']),
            'text' => $text,
            'reply_markup' => $this->takeover_keyboard($visitor_session)
        ];
        if ($thread_id !== '') {
            $payload['message_thread_id'] = intval($thread_id);
        }

        $response = wp_remote_post('https://api.telegram.org/bot' . trim($s['telegram_bot_token']) . '/sendMessage', [
            'timeout' => 20,
            'body' => $payload
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $decoded = json_decode($body, true);

        if ($code < 200 || $code >= 300 || empty($decoded['ok'])) {
            $description = $decoded['description'] ?? ('HTTP ' . $code . ' - ' . $body);
            return new WP_Error('mslc_telegram_api_error', $description);
        }

        return true;
    }
}
new MSLC_Plugin();
