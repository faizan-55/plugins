(function($){
  function newSessionId(){return 'chat_'+Date.now()+'_'+Math.random().toString(36).slice(2,10);}  
  let session = newSessionId();
  let lastAdminMessageId = 0;
  let sending = false;
  let started = false;
  let selectedFile = null;
  let clientToken = (Date.now().toString(36) + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2));

  function escapeHtml(t){return String(t||'').replace(/[&<>'"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c];});}
  function scrollBottom(){let b=$('.mslc-body'); if(b.length) b.scrollTop(b[0].scrollHeight);}
  function adminAvatar(){return MSLC_DATA.admin_avatar_url || '';}
  function avatarHtml(type){
    if(type==='user') return '<div class="mslc-avatar-small">'+escapeHtml(MSLC_DATA.widget_icon || '💬')+'</div>';
    let img=adminAvatar();
    let inner = img ? '<img class="mslc-avatar-small" src="'+escapeHtml(img)+'" alt="Admin">' : '<div class="mslc-avatar-small">💬</div>';
    return '<span class="mslc-avatar-online-wrap mslc-avatar-online-small">'+inner+'<span class="mslc-online-dot" aria-hidden="true"></span></span>';
  }
  function linkifyAttachments(htmlText){
    htmlText = String(htmlText||'').replace(/Attachment:\s*(https?:\/\/[^\s<]+)/gi,function(_,url){
      let clean=escapeHtml(url);
      let isImg=/\.(png|jpe?g|gif|webp)(\?.*)?$/i.test(url);
      return isImg ? 'Attachment:<br><img class="mslc-attachment-img" src="'+clean+'" alt="Attachment">' : 'Attachment: <a class="mslc-attachment-link" href="'+clean+'" target="_blank" rel="noopener">Open file</a>';
    });
    return htmlText;
  }
  function addMsg(text,type,attachmentUrl){
    if(!text && !attachmentUrl) return;
    let safe=escapeHtml(text || '').replace(/\n/g,'<br>');
    safe=linkifyAttachments(safe);
    if(attachmentUrl){
      let clean=escapeHtml(attachmentUrl);
      if(/\.(png|jpe?g|gif|webp)(\?.*)?$/i.test(attachmentUrl)){ safe += '<img class="mslc-attachment-img" src="'+clean+'" alt="Attachment">'; }
      else { safe += '<a class="mslc-attachment-link" href="'+clean+'" target="_blank" rel="noopener">Open attachment</a>'; }
    }
    let rowType = type==='user' ? 'mslc-row-user' : 'mslc-row-bot';
    let bubbleType = type==='user' ? 'user' : (type==='admin' ? 'admin' : 'bot');
    $('.mslc-body').append('<div class="mslc-row '+rowType+'">'+avatarHtml(type)+'<div class="mslc-msg mslc-'+bubbleType+'">'+safe+'</div></div>');
    scrollBottom();
  }
  function addTyping(type){
    let id='mslc_typing_'+Date.now()+'_'+Math.random().toString(36).slice(2,7);
    let rowType = type==='user' ? 'mslc-row-user' : 'mslc-row-bot';
    $('.mslc-body').append('<div class="mslc-row '+rowType+'" id="'+id+'_row">'+avatarHtml(type)+'<div id="'+id+'" class="mslc-msg mslc-'+(type||'bot')+' mslc-typing"><span></span><span></span><span></span></div></div>');
    scrollBottom();
    return id;
  }
  function humanDelay(text){let len=String(text||'').length;let delay=800+Math.min(1400,len*18)+Math.floor(Math.random()*650);return Math.max(900,Math.min(delay,2800));}
  function addMsgWithTyping(text,type){if(!text) return;let typingId=addTyping(type||'bot');setTimeout(function(){$('#'+typingId+'_row').remove();addMsg(text,type||'bot');},humanDelay(text));}
  function ajaxErrorText(xhr,fallback){let msg='';if(xhr&&xhr.responseJSON){if(xhr.responseJSON.data&&xhr.responseJSON.data.message)msg=xhr.responseJSON.data.message;else if(xhr.responseJSON.message)msg=xhr.responseJSON.message;}if(!msg&&xhr&&xhr.responseText){try{let parsed=JSON.parse(xhr.responseText);if(parsed&&parsed.data&&parsed.data.message)msg=parsed.data.message;}catch(e){}}return msg||fallback||'Sorry, can you send that again?';}
  function openChat(){$('#mslc-chat-box').addClass('mslc-open').show();$('#mslc-mobile-popup').hide();$('.mslc-input').focus();}
  function startChat(){if(started) return;started=true;$.post(MSLC_DATA.ajax_url,{action:'mslc_start_chat',nonce:MSLC_DATA.nonce,session:session,client_token:clientToken,_:Date.now()},function(res){if(res&&res.success&&res.data){if(res.data.session){session=String(res.data.session);}addMsg(res.data.text||'How can I help you?','bot');}else{addMsg('How can I help you?','bot');}}).fail(function(xhr){addMsg(ajaxErrorText(xhr,'How can I help you?'),'bot');});}
  function sendMessage(msg){
    if(sending) return;
    if(!msg && !selectedFile) return;
    sending=true;
    let previewUrl = selectedFile && selectedFile.type.indexOf('image/')===0 ? URL.createObjectURL(selectedFile) : '';
    addMsg(msg || (selectedFile ? selectedFile.name : ''),'user',previewUrl);
    let fd=new FormData();
    fd.append('action','mslc_send_message');fd.append('nonce',MSLC_DATA.nonce);fd.append('session',session);fd.append('client_token',clientToken);fd.append('message',msg);fd.append('_',Date.now());
    if(selectedFile) fd.append('attachment',selectedFile);
    selectedFile=null;$('.mslc-file').val('');$('.mslc-file-name').hide().text('');
    $.ajax({url:MSLC_DATA.ajax_url,type:'POST',data:fd,processData:false,contentType:false,success:function(res){if(res&&res.success&&res.data){if(res.data.session){session=String(res.data.session);}if(res.data.text){addMsgWithTyping(res.data.text,'bot');}}else if(res&&res.data&&res.data.message){addMsgWithTyping(res.data.message,'bot');}},error:function(xhr){addMsgWithTyping(ajaxErrorText(xhr,'Sorry, can you send that again?'),'bot');},complete:function(){sending=false;pollAdminMessages();}});
  }
  function handleIncomingMessages(res){let messages=[];if(res&&res.success&&res.data&&Array.isArray(res.data.messages))messages=res.data.messages;if(res&&res.ok&&Array.isArray(res.messages))messages=res.messages;messages.forEach(function(m){let id=Number(m.id||0);if(id&&id<=lastAdminMessageId)return;if(id){lastAdminMessageId=id;}addMsg(m.message,'admin');if(window.matchMedia('(max-width: 768px)').matches&&!$('#mslc-chat-box').is(':visible')){$('#mslc-mobile-popup').text('New message').show();}});}
  function pollAdminMessages(){if(!session)return;$.post(MSLC_DATA.ajax_url,{action:'mslc_get_messages',nonce:MSLC_DATA.nonce,session:session,client_token:clientToken,last_id:lastAdminMessageId,_:Date.now()},function(res){handleIncomingMessages(res);}).always(function(){if(MSLC_DATA.rest_messages_url){$.get(MSLC_DATA.rest_messages_url,{session:session,last_id:lastAdminMessageId,_:Date.now()},function(res){handleIncomingMessages(res);});}});}
  function buildWidget(){
    let img=adminAvatar();
    let avatarLargeInner=img?'<img class="mslc-avatar-large" src="'+escapeHtml(img)+'" alt="Admin">':'<div class="mslc-avatar-large">'+escapeHtml(MSLC_DATA.widget_icon||'💬')+'</div>';
    let avatarLarge='<div class="mslc-avatar-online-wrap mslc-avatar-online-large">'+avatarLargeInner+'<span class="mslc-online-dot mslc-online-dot-large" aria-hidden="true"></span></div>';
    let emojis=['😀','😃','😄','😁','😆','😅','😂','🤣','😊','🙂','🙃','😉','😍','🥰','😘','😎','🤔','🤗','😇','😐','😕','😢','😭','😡','😴','👍','👎','👌','👏','🙏','🙌','🤝','💪','👋','✅','❌','⭐','🔥','💯','🎉','❤️','🧡','💛','💚','💙','💜','🖤','🤍','📍','📞','💬','📧','📎','📷','🖼️','📄','📁','🏠','🏢','🚚','🚗','🛠️','🔧','⚡','💡','🚿','🧹','📅','⏰','💵','📝','🔒','📌'];
    let emojiBtns=emojis.map(function(e){return '<button type="button" class="mslc-emoji" data-emoji="'+e+'" aria-label="'+e+'">'+e+'</button>';}).join('');
    $('body').append('<div id="mslc-mobile-popup">Need help? Chat with us</div><div id="mslc-chat-button">'+escapeHtml(MSLC_DATA.widget_icon||'💬')+'</div><div id="mslc-chat-box"><div class="mslc-top"><div class="mslc-header-row"><div class="mslc-header-pill">💬 '+escapeHtml(MSLC_DATA.website_name||'Messages')+'</div><span class="mslc-close">×</span></div>'+avatarLarge+'<div class="mslc-title">'+escapeHtml(MSLC_DATA.chat_header_title||'Questions? Chat with us.')+'</div></div><div class="mslc-body"></div><div class="mslc-footer"><div class="mslc-input-wrap"><div class="mslc-file-name"></div><div class="mslc-emoji-panel">'+emojiBtns+'</div><div class="mslc-input-row"><textarea class="mslc-input" rows="1" placeholder="Compose your message..."></textarea><button type="button" class="mslc-send" title="Send">➤</button></div><div class="mslc-tools"><button type="button" class="mslc-tool mslc-emoji-toggle" title="Emoji">☺</button><button type="button" class="mslc-tool mslc-attach" title="Attach file">📎</button><input type="file" class="mslc-file" accept="image/jpeg,image/png,image/gif,image/webp,image/avif,.jpg,.jpeg,.png,.gif,.webp,.avif,.pdf,.doc,.docx,.xls,.xlsx,.csv,.txt,.rtf,.ppt,.pptx,.zip" style="display:none"></div></div></div></div>');
  }
  $(document).ready(function(){
    buildWidget();
    if(window.matchMedia('(min-width: 769px)').matches){openChat();}else{$('#mslc-mobile-popup').show();}
    startChat();
    $('#mslc-chat-button,#mslc-mobile-popup').on('click',function(e){e.stopPropagation();if($('#mslc-chat-box').is(':visible')){$('#mslc-chat-box').removeClass('mslc-open').hide();if(window.matchMedia('(max-width: 768px)').matches)$('#mslc-mobile-popup').show();}else{openChat();}});
    $(document).on('click','.mslc-close',function(e){e.stopPropagation();$('#mslc-chat-box').removeClass('mslc-open').hide();if(window.matchMedia('(max-width: 768px)').matches)$('#mslc-mobile-popup').show();});
    $(document).on('click touchstart',function(e){if(!$('#mslc-chat-box').is(':visible'))return;if($(e.target).closest('#mslc-chat-box,#mslc-chat-button,#mslc-mobile-popup').length)return;$('#mslc-chat-box').removeClass('mslc-open').hide();if(window.matchMedia('(max-width: 768px)').matches)$('#mslc-mobile-popup').show();});
    $(document).on('click touchstart','#mslc-chat-box',function(e){e.stopPropagation();});
    $(document).on('click','.mslc-send',function(){let v=$('.mslc-input').val().trim();if(v||selectedFile){$('.mslc-input').val('');sendMessage(v);}});
    $(document).on('keydown','.mslc-input',function(e){if(e.which===13&&!e.shiftKey){e.preventDefault();$('.mslc-send').click();}});
    $(document).on('input','.mslc-input',function(){this.style.height='auto';this.style.height=Math.min(this.scrollHeight,92)+'px';});
    $(document).on('click','.mslc-emoji-toggle',function(){ $('.mslc-emoji-panel').toggleClass('mslc-emoji-open'); });
    $(document).on('click touchend','.mslc-emoji',function(e){e.preventDefault();e.stopPropagation();let input=$('.mslc-input')[0];let emoji=$(this).attr('data-emoji')||$(this).text();if(input){input.focus();if(typeof input.setRangeText==='function'&&typeof input.selectionStart==='number'){let pos=input.selectionStart;input.setRangeText(emoji,input.selectionStart,input.selectionEnd,'end');input.selectionStart=input.selectionEnd=pos+emoji.length;}else{input.value=(input.value||'')+emoji;}}$('.mslc-input').trigger('input').focus();});
    $(document).on('click','.mslc-attach',function(){ $('.mslc-file').click(); });
    $(document).on('change','.mslc-file',function(){selectedFile=this.files&&this.files[0]?this.files[0]:null;if(selectedFile){$('.mslc-file-name').text('Attached: '+selectedFile.name).show();}else{$('.mslc-file-name').hide().text('');}});
    setInterval(pollAdminMessages,1000);pollAdminMessages();
  });
})(jQuery);
